// Direction A — Part 2: Shop, Recensioni, Dove, Contatti, Footer

// ────────────────────────────────────────────────────────────
// Shop section
const ShopA = ({ onAdd }) => {
  const [cat, setCat] = useState("Tutti");
  const cats = useMemo(() => ["Tutti", ...new Set(PRODOTTI.map(p => p.cat))], []);
  const shown = cat === "Tutti" ? PRODOTTI : PRODOTTI.filter(p => p.cat === cat);
  return (
    <section id="shop" style={{ background: A.yellow, padding: "100px 0", position: "relative", overflow: "hidden" }}>
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `repeating-linear-gradient(90deg, transparent 0 80px, ${A.yellowDeep}22 80px 82px)`,
      }} />
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px", position: "relative" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 20 }}>
          <SectionHeaderA kicker="03 / Shop" title="ORDINA, PASSA, RITIRA." />
          <p style={{ maxWidth: 380, color: A.black, fontSize: 15, margin: 0 }}>
            Una selezione di quello che trovi in negozio. <b>Consegna in zona</b> oppure ritiro in bottega.
          </p>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 40, marginBottom: 30 }}>
          {cats.map(c => (
            <button key={c} onClick={() => setCat(c)} style={{
              padding: "10px 18px",
              background: cat === c ? A.blue : "#fff", color: cat === c ? A.yellow : A.blue,
              border: `2px solid ${A.black}`, boxShadow: `3px 3px 0 ${A.black}`,
              fontWeight: 800, fontSize: 13, cursor: "pointer", fontFamily: "inherit",
              textTransform: "uppercase", letterSpacing: "0.05em",
            }}>{c}</button>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: 16 }}>
          {shown.map((p, i) => <ProductCardA key={p.id} p={p} i={i} onAdd={onAdd} />)}
        </div>
      </div>
    </section>
  );
};

const ProductCardA = ({ p, i, onAdd }) => {
  const [ref, inView] = useInView();
  const [hover, setHover] = useState(false);
  const [added, setAdded] = useState(false);
  const handleAdd = () => {
    onAdd(p);
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  };
  return (
    <div ref={ref}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: "#fff", border: `3px solid ${A.black}`,
        boxShadow: hover ? `10px 10px 0 ${A.black}` : `5px 5px 0 ${A.black}`,
        display: "flex", flexDirection: "column",
        opacity: inView ? 1 : 0,
        transform: inView ? (hover ? "translate(-5px,-5px)" : "translate(0,0)") : "translateY(30px)",
        transition: `opacity .6s ${i * 0.03}s, transform .2s, box-shadow .2s`,
        position: "relative",
      }}>
      {p.offerta && (
        <span style={{
          position: "absolute", top: 10, right: 10, zIndex: 2,
          background: A.red, color: "#fff", padding: "4px 10px",
          fontWeight: 900, fontSize: 12, border: `2px solid ${A.black}`,
          transform: "rotate(4deg)",
        }}>OFFERTA</span>
      )}
      <div style={{
        aspectRatio: "1", background: p.colore,
        display: "grid", placeItems: "center",
        fontSize: 80, borderBottom: `3px solid ${A.black}`,
      }}>
        {p.emoji}
      </div>
      <div style={{ padding: 16, flex: 1, display: "flex", flexDirection: "column" }}>
        <div style={{ fontSize: 11, fontWeight: 800, color: A.red, letterSpacing: "0.1em" }}>{p.cat.toUpperCase()}</div>
        <h4 style={{ margin: "4px 0 12px", fontSize: 16, fontWeight: 800, color: A.black, lineHeight: 1.25, flex: 1 }}>{p.nome}</h4>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 12 }}>
          <div>
            {p.prezzoVecchio && <span style={{ textDecoration: "line-through", opacity: 0.5, fontSize: 14, marginRight: 6 }}>€{p.prezzoVecchio.toFixed(2)}</span>}
            <span style={{ fontSize: 22, fontWeight: 900, color: A.blue, fontFamily: "'Archivo Black', Impact, sans-serif" }}>€{p.prezzo.toFixed(2)}</span>
          </div>
        </div>
        <button onClick={handleAdd} style={{
          background: added ? A.green : A.blue, color: A.yellow,
          border: `2px solid ${A.black}`, padding: "10px 12px",
          fontWeight: 900, fontSize: 13, cursor: "pointer", fontFamily: "inherit",
          display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          transition: "background .2s",
        }}>
          {added ? <><Icon name="check" size={16} stroke={A.yellow} /> AGGIUNTO</> : <><Icon name="plus" size={16} stroke={A.yellow} /> AL CARRELLO</>}
        </button>
      </div>
    </div>
  );
};

// ────────────────────────────────────────────────────────────
// Recensioni marquee
const RecensioniA = () => {
  const rows = [RECENSIONI.slice(0, 8), RECENSIONI.slice(8, 16)];
  return (
    <section id="recensioni" style={{ background: A.cream, padding: "100px 0", overflow: "hidden" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px", marginBottom: 50 }}>
        <SectionHeaderA kicker="04 / Cosa dicono i clienti" title="PAROLE DI CHI CI CONOSCE." />
        <div style={{ marginTop: 24, display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ display: "flex", gap: 3 }}>{[1,2,3,4,5].map(s => <Icon key={s} name="star" size={28} stroke={A.yellowDeep} />)}</div>
          <span style={{ fontSize: 20, fontWeight: 900, color: A.blue }}>4.9 / 5</span>
          <span style={{ color: A.black, opacity: 0.7 }}>— da oltre 60 recensioni Google verificate</span>
        </div>
      </div>
      {rows.map((row, ri) => (
        <div key={ri} style={{
          display: "flex", gap: 20, marginBottom: 20,
          animation: `scroll-left ${40 + ri * 10}s linear infinite`,
          animationDirection: ri % 2 === 0 ? "normal" : "reverse",
          width: "max-content",
        }}>
          {[...row, ...row].map((r, i) => <ReviewCardA key={`${ri}-${i}`} r={r} />)}
        </div>
      ))}
    </section>
  );
};

const ReviewCardA = ({ r }) => {
  const bg = ["#fff", A.yellow, A.blue][Math.floor(Math.random() * 3)];
  const fg = bg === A.blue ? A.yellow : A.black;
  return (
    <div style={{
      width: 380, flexShrink: 0,
      background: bg, color: fg,
      border: `3px solid ${A.black}`, boxShadow: `6px 6px 0 ${A.black}`,
      padding: 24, position: "relative",
    }}>
      <Icon name="quote" size={28} stroke={bg === A.blue ? A.yellow : A.blue} />
      <p style={{ fontSize: 15, lineHeight: 1.5, margin: "12px 0 16px", minHeight: 90 }}>"{r.testo}"</p>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderTop: `2px dashed ${fg}`, paddingTop: 12 }}>
        <div>
          <div style={{ fontWeight: 900, fontSize: 14 }}>{r.nome}</div>
          <div style={{ fontSize: 12, opacity: 0.7 }}>{r.quando}</div>
        </div>
        <div style={{ display: "flex", gap: 2 }}>{Array.from({ length: r.stelle }).map((_, i) => <Icon key={i} name="star" size={14} stroke={bg === A.yellow ? A.blue : A.yellowDeep} />)}</div>
      </div>
    </div>
  );
};

// ────────────────────────────────────────────────────────────
// Dove siamo + Contatti
const DoveA = () => {
  return (
    <section id="dove" style={{ background: A.black, color: A.yellow, padding: "100px 0", position: "relative" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px" }}>
        <SectionHeaderA kicker="05 / Dove siamo" title="PASSA A TROVARCI." dark />
        <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 32, marginTop: 60 }}>
          <div style={{
            border: `4px solid ${A.yellow}`,
            boxShadow: `8px 8px 0 ${A.blue}`,
            overflow: "hidden",
            aspectRatio: "1.4",
            background: "#ddd",
          }}>
            <iframe
              src="https://www.openstreetmap.org/export/embed.html?bbox=7.6508%2C45.0731%2C7.6588%2C45.0791&layer=mapnik&marker=45.0761%2C7.6548"
              style={{ border: 0, width: "100%", height: "100%", display: "block" }}
              loading="lazy"
              title="Mappa Ferramenta Aruga"
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <InfoBoxA icon="pin" title="INDIRIZZO" big="Via Graglia, 6" small="10136 Torino, Italia" href="https://www.google.com/maps?q=Via+Graglia+6+Torino" cta="APRI IN MAPPE" />
            <InfoBoxA icon="phone" title="TELEFONO" big="011 353934" small="Chiamaci, siamo sempre al banco" href="tel:+390113539340" cta="CHIAMA ORA" />
            <div style={{ background: A.yellow, color: A.blue, border: `3px solid ${A.yellow}`, padding: 20 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13, fontWeight: 900, letterSpacing: "0.1em", marginBottom: 12 }}>
                <Icon name="clock" size={18} stroke={A.blue} /> ORARI
              </div>
              {CONTATTI.orari.map(o => (
                <div key={o.g} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", fontSize: 14, borderBottom: `1px dashed ${A.blue}55` }}>
                  <span style={{ fontWeight: 700 }}>{o.g}</span>
                  <span>{o.h}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const InfoBoxA = ({ icon, title, big, small, href, cta }) => (
  <a href={href} target="_blank" rel="noopener" style={{
    background: A.blue, color: A.yellow,
    border: `3px solid ${A.yellow}`, padding: 20,
    textDecoration: "none", display: "block",
    transition: "transform .15s",
  }}
  onMouseEnter={e => e.currentTarget.style.transform = "translate(-3px,-3px)"}
  onMouseLeave={e => e.currentTarget.style.transform = ""}
  >
    <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13, fontWeight: 900, letterSpacing: "0.1em" }}>
      <Icon name={icon} size={18} stroke={A.yellow} /> {title}
    </div>
    <div style={{ fontSize: 28, fontWeight: 900, margin: "8px 0 4px", fontFamily: "'Archivo Black', Impact, sans-serif", letterSpacing: "-0.02em" }}>{big}</div>
    <div style={{ fontSize: 14, opacity: 0.85 }}>{small}</div>
    <div style={{ marginTop: 10, fontSize: 12, fontWeight: 900, letterSpacing: "0.1em", display: "inline-flex", alignItems: "center", gap: 6 }}>
      {cta} <Icon name="arrow" size={14} stroke={A.yellow} />
    </div>
  </a>
);

// ────────────────────────────────────────────────────────────
// Galleria
const GalleriaA = () => {
  const tiles = [
    { bg: A.yellow, icon: "hammer", label: "UTENSILERIA" },
    { bg: A.blue, icon: "drill", label: "ELETTROUTENSILI" },
    { bg: A.red, icon: "key", label: "DUPLICAZIONE CHIAVI" },
    { bg: A.cream, icon: "paint", label: "VERNICI & COLORI" },
    { bg: A.blue, icon: "bolt", label: "MINUTERIA" },
    { bg: A.yellow, icon: "leaf", label: "GIARDINAGGIO" },
  ];
  return (
    <section id="galleria" style={{ background: "#fff", padding: "100px 0" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px" }}>
        <SectionHeaderA kicker="06 / Galleria" title="DENTRO LA BOTTEGA." />
        <p style={{ color: A.black, maxWidth: 540, fontSize: 15, marginTop: 16, opacity: 0.7 }}>
          Piccola fuori, infinita dentro. Qualche scorcio del negozio — dai cassetti della minuteria al banco della duplicazione chiavi.
        </p>
        <div style={{ marginTop: 50, display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gridAutoRows: "260px", gap: 16 }}>
          {tiles.map((t, i) => <GalleryTileA key={i} t={t} i={i} />)}
        </div>
      </div>
    </section>
  );
};

const GalleryTileA = ({ t, i }) => {
  const [ref, inView] = useInView();
  const [hover, setHover] = useState(false);
  const fg = t.bg === A.blue || t.bg === A.red ? A.yellow : A.blue;
  return (
    <div ref={ref}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: t.bg, border: `3px solid ${A.black}`,
        boxShadow: `6px 6px 0 ${A.black}`,
        display: "grid", placeItems: "center", position: "relative", overflow: "hidden",
        opacity: inView ? 1 : 0,
        transform: inView ? "scale(1)" : "scale(0.9)",
        transition: `all .6s ${i * 0.08}s`,
        cursor: "pointer",
      }}>
      <div style={{ transform: hover ? "scale(1.1) rotate(-5deg)" : "scale(1)", transition: "transform .4s", color: fg }}>
        <Icon name={t.icon} size={120} stroke={fg} sw={2} />
      </div>
      <div style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        background: A.black, color: A.yellow,
        padding: "12px 16px", fontWeight: 900, fontSize: 14, letterSpacing: "0.1em",
        transform: hover ? "translateY(0)" : "translateY(100%)",
        transition: "transform .3s",
      }}>{t.label} →</div>
    </div>
  );
};

// ────────────────────────────────────────────────────────────
// Footer / CTA
const FooterA = () => (
  <footer id="contatti" style={{ background: A.blue, color: A.yellow, padding: "80px 0 30px", position: "relative", overflow: "hidden" }}>
    <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px" }}>
      <div style={{
        border: `4px solid ${A.yellow}`,
        padding: "60px 40px",
        textAlign: "center",
        background: A.blueDeep,
        boxShadow: `10px 10px 0 ${A.yellow}, 10px 10px 0 3px ${A.black}`,
        marginBottom: 60,
      }}>
        <div style={{ fontSize: 14, letterSpacing: "0.2em", fontWeight: 800, color: A.yellow }}>◉ NON ESITARE</div>
        <h3 style={{
          fontSize: "clamp(40px, 6vw, 80px)", fontWeight: 900, margin: "12px 0",
          lineHeight: 0.95, letterSpacing: "-0.03em",
          fontFamily: "'Archivo Black', Impact, sans-serif", color: A.yellow,
        }}>PASSA DA ARUGA.</h3>
        <p style={{ fontSize: 18, color: "#fff", maxWidth: 560, margin: "0 auto 30px", opacity: 0.9 }}>
          Un consiglio, una chiave, una mensola che non sta su. Veniamo incontro a tutti — come nel 1986.
        </p>
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap", justifyContent: "center" }}>
          <a href="https://www.google.com/maps?q=Via+Graglia+6+Torino" target="_blank" rel="noopener" style={btnA(A.yellow, A.blue)}>
            <Icon name="pin" size={18} stroke={A.blue} /> VIA GRAGLIA 6, TORINO
          </a>
          <a href="tel:+390113539340" style={btnA("#fff", A.blue)}>
            <Icon name="phone" size={18} stroke={A.blue} /> 011 353934
          </a>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 30, paddingBottom: 30, borderBottom: `2px solid ${A.yellow}33` }}>
        <div>
          <div style={{ fontSize: 28, fontWeight: 900, letterSpacing: "-0.02em", fontFamily: "'Archivo Black', Impact, sans-serif" }}>FERRAMENTA ARUGA</div>
          <div style={{ fontSize: 14, opacity: 0.7, marginTop: 4 }}>La bottega di Via Graglia, dal 1986.</div>
          <div style={{ marginTop: 20, display: "flex", gap: 10 }}>
            <SocialA icon="facebook" />
            <SocialA icon="instagram" />
            <SocialA icon="whatsapp" />
          </div>
        </div>
        <FooterColA title="NEGOZIO" items={["Servizi", "Shop", "Chi siamo", "Galleria"]} />
        <FooterColA title="CONTATTI" items={["Via Graglia 6, Torino", "011 353934", "Lun-Ven 9-19", "Sab 9-12:30"]} />
        <FooterColA title="LEGALE" items={["P. IVA", "Privacy", "Cookie", "Termini"]} />
      </div>
      <div style={{ paddingTop: 20, textAlign: "center", fontSize: 12, opacity: 0.6 }}>
        © 2026 Ferramenta Aruga · Via Graglia 6, 10136 Torino · P.IVA 0000000000 · Sito creato con ♥ in bottega
      </div>
    </div>
  </footer>
);

const SocialA = ({ icon }) => (
  <a href="#" style={{
    width: 44, height: 44, display: "grid", placeItems: "center",
    background: A.yellow, color: A.blue,
    border: `2px solid ${A.yellow}`, transition: "transform .15s",
  }}
  onMouseEnter={e => { e.currentTarget.style.transform = "translate(-2px,-2px)"; e.currentTarget.style.boxShadow = `3px 3px 0 ${A.black}`; }}
  onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
  >
    <Icon name={icon} size={22} stroke={A.blue} />
  </a>
);

const FooterColA = ({ title, items }) => (
  <div>
    <div style={{ fontSize: 13, fontWeight: 900, letterSpacing: "0.15em", marginBottom: 12 }}>{title}</div>
    <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
      {items.map(i => <li key={i} style={{ fontSize: 14, padding: "3px 0", opacity: 0.85 }}>{i}</li>)}
    </ul>
  </div>
);

// ────────────────────────────────────────────────────────────
// Cart drawer
const CartDrawer = ({ open, items, onClose, onRemove }) => {
  const total = items.reduce((s, x) => s + x.prezzo * x.qty, 0);
  return (
    <>
      <div style={{
        position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 200,
        opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none", transition: "opacity .3s",
      }} onClick={onClose} />
      <aside style={{
        position: "fixed", top: 0, right: 0, bottom: 0, width: "min(420px, 92vw)",
        background: A.yellow, borderLeft: `4px solid ${A.black}`, zIndex: 201,
        transform: open ? "translateX(0)" : "translateX(100%)", transition: "transform .35s",
        display: "flex", flexDirection: "column",
      }}>
        <div style={{ background: A.blue, color: A.yellow, padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: `3px solid ${A.black}` }}>
          <div style={{ fontSize: 22, fontWeight: 900, fontFamily: "'Archivo Black', Impact, sans-serif", letterSpacing: "-0.02em" }}>IL TUO CARRELLO</div>
          <button onClick={onClose} style={{ background: "transparent", border: "none", color: A.yellow, cursor: "pointer", padding: 4 }}>
            <Icon name="close" size={22} stroke={A.yellow} />
          </button>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: 16 }}>
          {items.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px", color: A.blue }}>
              <Icon name="cart" size={60} stroke={A.blue} sw={2} />
              <div style={{ fontWeight: 900, fontSize: 20, marginTop: 16 }}>Il carrello è vuoto</div>
              <div style={{ fontSize: 14, marginTop: 8, opacity: 0.7 }}>Aggiungi qualche prodotto dal nostro shop.</div>
            </div>
          ) : items.map(it => (
            <div key={it.id} style={{
              background: "#fff", border: `2px solid ${A.black}`, boxShadow: `3px 3px 0 ${A.black}`,
              padding: 12, marginBottom: 10, display: "flex", gap: 12, alignItems: "center",
            }}>
              <div style={{ width: 54, height: 54, background: it.colore, display: "grid", placeItems: "center", fontSize: 28, border: `2px solid ${A.black}` }}>{it.emoji}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: A.black, lineHeight: 1.2 }}>{it.nome}</div>
                <div style={{ fontSize: 12, color: A.black, opacity: 0.6, marginTop: 2 }}>Qtà: {it.qty}</div>
                <div style={{ fontSize: 14, fontWeight: 900, color: A.blue, marginTop: 2 }}>€{(it.prezzo * it.qty).toFixed(2)}</div>
              </div>
              <button onClick={() => onRemove(it.id)} style={{ background: "transparent", border: "none", cursor: "pointer", padding: 4 }}>
                <Icon name="close" size={18} stroke={A.red} />
              </button>
            </div>
          ))}
        </div>
        <div style={{ background: A.blue, color: A.yellow, padding: 20, borderTop: `3px solid ${A.black}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 22, fontWeight: 900, marginBottom: 14, fontFamily: "'Archivo Black', Impact, sans-serif" }}>
            <span>TOTALE</span>
            <span>€{total.toFixed(2)}</span>
          </div>
          <button disabled={items.length === 0} style={{
            width: "100%", padding: "16px", background: items.length ? A.yellow : "#888",
            color: A.blue, border: `2px solid ${A.black}`, boxShadow: `4px 4px 0 ${A.black}`,
            fontWeight: 900, fontSize: 16, cursor: items.length ? "pointer" : "not-allowed",
            fontFamily: "inherit", letterSpacing: "0.05em",
          }}>VAI AL CHECKOUT →</button>
        </div>
      </aside>
    </>
  );
};

Object.assign(window, { ShopA, RecensioniA, DoveA, GalleriaA, FooterA, CartDrawer });

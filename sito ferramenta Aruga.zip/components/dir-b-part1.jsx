// Direction B — EDITORIALE MODERNO
// Sfondo cream, tipografia mista (serif titoli + sans corpo), parallax forte, accenti giallo/blu minimali
// Animazioni: reveal scroll, numeri grandi editoriali, parallax livelli multipli, recensioni carousel elegante

const { useState: uB, useEffect: eB, useRef: rB, useMemo: mB } = React;

const B = {
  cream: "#F6F0E4",
  creamDark: "#EDE3CF",
  ink: "#1A1A1A",
  blue: "#243B7C",
  blueSoft: "#4A63A8",
  yellow: "#FFC61C",
  yellowSoft: "#FFE7A0",
  accent: "#D84315",
  white: "#FFFFFF",
};

// ── reveal hook (shared style)
const useRevealB = () => {
  const ref = rB(null);
  const [v, setV] = uB(false);
  eB(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setV(true); io.disconnect(); }}, { threshold: 0.15 });
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return [ref, v];
};

// ── Header
const HeaderB = ({ onCart, count }) => {
  const [scrolled, setScrolled] = uB(false);
  eB(() => {
    const h = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", h); return () => window.removeEventListener("scroll", h);
  }, []);
  const links = [["Servizi","#servizi-b"],["Catalogo","#shop-b"],["Storia","#chi-b"],["Recensioni","#recensioni-b"],["Dove","#dove-b"]];
  return (
    <header style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
      background: scrolled ? B.cream + "ee" : "transparent",
      backdropFilter: scrolled ? "blur(10px)" : "none",
      borderBottom: scrolled ? `1px solid ${B.ink}22` : "1px solid transparent",
      transition: "all .3s",
    }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "18px 32px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24 }}>
        <a href="#top-b" style={{ textDecoration: "none", color: B.ink, display: "flex", alignItems: "baseline", gap: 10 }}>
          <span style={{ fontSize: 22, fontWeight: 700, fontFamily: "'Fraunces', 'Playfair Display', Georgia, serif", letterSpacing: "-0.02em" }}>Aruga</span>
          <span style={{ fontSize: 11, color: B.blue, letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600 }}>Ferramenta · 1986</span>
        </a>
        <nav style={{ display: "flex", gap: 28 }}>
          {links.map(([l,h]) => (
            <a key={h} href={h} style={{ fontSize: 14, color: B.ink, textDecoration: "none", fontWeight: 500, position: "relative" }}
              onMouseEnter={e => e.currentTarget.style.color = B.blue}
              onMouseLeave={e => e.currentTarget.style.color = B.ink}
            >{l}</a>
          ))}
        </nav>
        <button onClick={onCart} style={{
          background: B.ink, color: B.cream, border: "none", padding: "11px 20px", borderRadius: 99,
          fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
          display: "flex", alignItems: "center", gap: 8,
        }}>
          <Icon name="cart" size={16} stroke={B.cream} /> Carrello {count > 0 && <span style={{ background: B.yellow, color: B.ink, borderRadius: 99, padding: "1px 7px", fontSize: 11, fontWeight: 700 }}>{count}</span>}
        </button>
      </div>
    </header>
  );
};

// ── Hero with parallax layers
const HeroB = () => {
  const [y, setY] = uB(0);
  eB(() => {
    const h = () => setY(window.scrollY);
    window.addEventListener("scroll", h, { passive: true }); return () => window.removeEventListener("scroll", h);
  }, []);
  return (
    <section id="top-b" style={{ position: "relative", minHeight: "105vh", background: B.cream, overflow: "hidden", paddingTop: 110 }}>
      {/* floating parallax shapes */}
      <div style={{ position: "absolute", top: 140, right: "8%", transform: `translateY(${-y * 0.3}px) rotate(${y * 0.05}deg)`, color: B.blue, opacity: 0.08 }}>
        <Icon name="hammer" size={300} stroke={B.blue} sw={1.5} />
      </div>
      <div style={{ position: "absolute", bottom: 100, left: "5%", transform: `translateY(${-y * 0.15}px)`, color: B.yellow }}>
        <Icon name="bolt" size={140} stroke={B.yellow} sw={1.5} />
      </div>
      <div style={{ position: "absolute", top: 280, left: "42%", transform: `translateY(${-y * 0.45}px) rotate(-8deg)`, color: B.accent, opacity: 0.2 }}>
        <Icon name="key" size={90} stroke={B.accent} sw={2} />
      </div>

      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "80px 32px", position: "relative" }}>
        <div style={{ fontSize: 13, color: B.accent, fontWeight: 600, letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: 30, display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ width: 40, height: 1, background: B.accent }}/> Via Graglia 6 · Torino · dal 1986
        </div>
        <h1 style={{
          fontSize: "clamp(64px, 11vw, 200px)",
          fontFamily: "'Fraunces', 'Playfair Display', Georgia, serif",
          fontWeight: 400, fontStyle: "italic",
          lineHeight: 0.92, color: B.ink, letterSpacing: "-0.045em",
          margin: 0,
        }}>
          La bottega<br/>
          <span style={{ fontStyle: "normal", fontWeight: 900 }}>che risolve.</span>
        </h1>

        <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 80, marginTop: 60, alignItems: "end" }}>
          <p style={{ fontSize: 20, lineHeight: 1.55, color: B.ink, opacity: 0.8, maxWidth: 540, margin: 0 }}>
            Da quasi <b>quarant'anni</b>, in via Graglia, siamo il negozio di ferramenta del quartiere. 
            Utensili, vernici, chiavi, consigli. Un posto dove si risponde — non si rimanda.
          </p>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            <a href="#dove-b" style={btnB("solid")}>
              Passa a trovarci <Icon name="arrow" size={16} stroke={B.cream} />
            </a>
            <a href="#shop-b" style={btnB("ghost")}>
              Vedi il catalogo
            </a>
          </div>
        </div>

        {/* marquee ribbon */}
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, background: B.blue, color: B.cream, transform: "translateY(50%) rotate(-1.5deg)", padding: "18px 0", overflow: "hidden" }}>
          <div style={{ display: "flex", gap: 60, animation: "scroll-left 35s linear infinite", whiteSpace: "nowrap" }}>
            {Array.from({ length: 6 }).map((_, k) => (
              <span key={k} style={{ fontSize: 20, fontFamily: "'Fraunces', serif", fontStyle: "italic", display: "inline-flex", alignItems: "center", gap: 60 }}>
                Utensili · Elettroutensili · Idraulica · Elettricità · Chiavi · Vernici · Giardinaggio · Casalinghi · Bulloneria · Riparazioni ·
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const btnB = (kind) => kind === "solid" ? ({
  display: "inline-flex", alignItems: "center", gap: 10,
  background: B.ink, color: B.cream, padding: "16px 28px", borderRadius: 99,
  fontSize: 15, fontWeight: 600, textDecoration: "none", transition: "all .15s",
}) : ({
  display: "inline-flex", alignItems: "center", gap: 10,
  background: "transparent", color: B.ink, padding: "16px 28px", borderRadius: 99,
  border: `1.5px solid ${B.ink}`, fontSize: 15, fontWeight: 600, textDecoration: "none",
});

// ── Servizi — editorial list with numbered rows
const ServiziB = () => {
  const [ref, v] = useRevealB();
  return (
    <section id="servizi-b" style={{ background: B.creamDark, padding: "140px 0 120px" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 80, marginBottom: 80 }}>
          <div>
            <div style={{ fontSize: 12, color: B.accent, letterSpacing: "0.25em", fontWeight: 600, textTransform: "uppercase" }}>— Cosa facciamo</div>
            <h2 style={{ fontSize: "clamp(44px, 6vw, 80px)", fontFamily: "'Fraunces', serif", fontWeight: 400, fontStyle: "italic", lineHeight: 1, color: B.ink, letterSpacing: "-0.04em", marginTop: 16 }}>
              Undici reparti,<br/>un solo <span style={{ fontStyle: "normal", fontWeight: 900 }}>banco.</span>
            </h2>
          </div>
          <p style={{ fontSize: 18, lineHeight: 1.6, color: B.ink, opacity: 0.75, alignSelf: "end", maxWidth: 520 }}>
            Non siamo un grande magazzino. Siamo un negozio piccolo, ordinato, pensato: dentro c'è tutto il necessario, e se manca, si ordina. Sotto, i reparti — ma soprattutto, chiedici: il consiglio è incluso.
          </p>
        </div>
        <div ref={ref}>
          {SERVIZI.map((s, i) => <ServiceRowB key={s.id} s={s} i={i} v={v} />)}
        </div>
      </div>
    </section>
  );
};

const ServiceRowB = ({ s, i, v }) => {
  const [hover, setHover] = uB(false);
  return (
    <div
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: "grid", gridTemplateColumns: "80px 1fr auto 60px",
        gap: 24, alignItems: "center",
        padding: "28px 16px",
        borderTop: `1px solid ${B.ink}22`,
        borderBottom: i === SERVIZI.length - 1 ? `1px solid ${B.ink}22` : "none",
        opacity: v ? 1 : 0, transform: v ? "translateY(0)" : "translateY(20px)",
        transition: `all .5s ${i * 0.04}s`,
        background: hover ? B.cream : "transparent",
        cursor: "pointer",
    }}>
      <div style={{ fontSize: 13, color: B.accent, fontWeight: 700, letterSpacing: "0.1em", fontFamily: "'Fraunces', serif", fontStyle: "italic" }}>№ {String(i+1).padStart(2, "0")}</div>
      <div>
        <h3 style={{ fontSize: 28, margin: 0, fontWeight: 500, color: B.ink, letterSpacing: "-0.02em", fontFamily: "'Fraunces', serif", fontStyle: hover ? "italic" : "normal", transition: "font-style .2s" }}>{s.titolo}</h3>
        <p style={{ fontSize: 15, color: B.ink, opacity: 0.65, margin: "4px 0 0", maxWidth: 600 }}>{s.desc}</p>
      </div>
      <div style={{ color: B.blue, opacity: hover ? 1 : 0.4, transition: "opacity .2s" }}>
        <Icon name={s.icon} size={36} stroke={B.blue} sw={1.5} />
      </div>
      <div style={{ textAlign: "right" }}>
        <div style={{ width: 40, height: 40, borderRadius: "50%", background: hover ? B.ink : "transparent", color: hover ? B.cream : B.ink, border: `1.5px solid ${B.ink}`, display: "grid", placeItems: "center", marginLeft: "auto", transition: "all .2s", transform: hover ? "translateX(5px)" : "none" }}>
          <Icon name="arrow" size={14} stroke={hover ? B.cream : B.ink} />
        </div>
      </div>
    </div>
  );
};

// ── Storia con parallax photo blocks
const StoriaB = () => {
  const [y, setY] = uB(0);
  eB(() => { const h = () => setY(window.scrollY); window.addEventListener("scroll", h, { passive: true }); return () => window.removeEventListener("scroll", h); }, []);
  const sectionRef = rB(null);
  const [ref, v] = useRevealB();
  return (
    <section id="chi-b" ref={sectionRef} style={{ background: B.cream, padding: "140px 0", position: "relative", overflow: "hidden" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80, alignItems: "center" }}>
        <div ref={ref} style={{ opacity: v ? 1 : 0, transition: "opacity .8s" }}>
          <div style={{ fontSize: 12, color: B.accent, letterSpacing: "0.25em", fontWeight: 600, textTransform: "uppercase", marginBottom: 16 }}>— Storia</div>
          <h2 style={{ fontSize: "clamp(48px, 6.5vw, 88px)", fontFamily: "'Fraunces', serif", fontWeight: 400, lineHeight: 1, color: B.ink, letterSpacing: "-0.04em", margin: 0 }}>
            Quarant'anni<br/>
            <span style={{ fontStyle: "italic" }}>al banco.</span>
          </h2>
          <p style={{ fontSize: 18, lineHeight: 1.7, color: B.ink, opacity: 0.8, marginTop: 28, maxWidth: 540 }}>
            Nel 1986 aprì una piccola ferramenta in via Graglia. Da allora è passato di tutto — generazioni di clienti, mille chiavi duplicate, migliaia di consigli. 
          </p>
          <p style={{ fontSize: 18, lineHeight: 1.7, color: B.ink, opacity: 0.8, marginTop: 12, maxWidth: 540 }}>
            "<span style={{ fontStyle: "italic", fontFamily: "'Fraunces', serif" }}>Robi e Robi che squadra! Hanno sempre una soluzione per il cliente, e quando non ce l'hanno la inventano nel retrobottega.</span>" — Angelo, cliente da 3 anni
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, marginTop: 50 }}>
            {[["1986","L'apertura"],["11","Reparti"],["4.9★","Voto Google"]].map(([big, sub], i) => (
              <div key={i} style={{ borderLeft: `2px solid ${B.blue}`, paddingLeft: 16 }}>
                <div style={{ fontSize: 44, fontFamily: "'Fraunces', serif", fontWeight: 500, color: B.ink, letterSpacing: "-0.03em" }}>{big}</div>
                <div style={{ fontSize: 13, color: B.ink, opacity: 0.6, marginTop: 2 }}>{sub}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ position: "relative", height: 560 }}>
          <div style={{
            position: "absolute", top: 0, right: 0, width: "75%", height: "60%",
            background: B.yellow, transform: `translateY(${-y * 0.06}px)`,
            display: "grid", placeItems: "center",
          }}>
            <div style={{ textAlign: "center", color: B.ink }}>
              <div style={{ fontSize: 110, fontFamily: "'Fraunces', serif", fontWeight: 900, letterSpacing: "-0.05em", lineHeight: 1 }}>'86</div>
              <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: "0.2em", marginTop: 8 }}>— ANNO DI FONDAZIONE —</div>
            </div>
          </div>
          <div style={{
            position: "absolute", bottom: 0, left: 0, width: "65%", height: "55%",
            background: B.blue, color: B.cream,
            transform: `translateY(${-y * 0.12}px)`,
            padding: 30, display: "flex", flexDirection: "column", justifyContent: "space-between",
          }}>
            <Icon name="quote" size={48} stroke={B.yellow} />
            <div>
              <p style={{ fontSize: 22, fontFamily: "'Fraunces', serif", fontStyle: "italic", lineHeight: 1.3, margin: 0 }}>
                "Come i negozi di una volta. Non è grandissimo ma dentro trovi di tutto."
              </p>
              <div style={{ fontSize: 13, marginTop: 20, opacity: 0.7, letterSpacing: "0.1em" }}>— LUCA Z., CLIENTE</div>
            </div>
          </div>
          <img src="assets/logo-aruga.jpeg" alt="Aruga" style={{
            position: "absolute", top: "40%", left: "45%", width: 160, height: 160,
            border: `4px solid ${B.cream}`, boxShadow: "0 20px 40px rgba(0,0,0,0.2)",
            transform: `translateY(${-y * 0.2}px) rotate(6deg)`,
          }} />
        </div>
      </div>
    </section>
  );
};

// ── Shop
const ShopB = ({ onAdd }) => {
  const [cat, setCat] = uB("Tutti");
  const cats = mB(() => ["Tutti", ...new Set(PRODOTTI.map(p => p.cat))], []);
  const shown = cat === "Tutti" ? PRODOTTI : PRODOTTI.filter(p => p.cat === cat);
  return (
    <section id="shop-b" style={{ background: B.creamDark, padding: "140px 0" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 50, flexWrap: "wrap", gap: 20 }}>
          <div>
            <div style={{ fontSize: 12, color: B.accent, letterSpacing: "0.25em", fontWeight: 600, textTransform: "uppercase" }}>— Catalogo</div>
            <h2 style={{ fontSize: "clamp(44px, 6vw, 80px)", fontFamily: "'Fraunces', serif", fontWeight: 400, lineHeight: 1, color: B.ink, letterSpacing: "-0.04em", marginTop: 16 }}>
              Una <span style={{ fontStyle: "italic" }}>selezione</span>.
            </h2>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {cats.map(c => (
              <button key={c} onClick={() => setCat(c)} style={{
                padding: "10px 18px", borderRadius: 99,
                background: cat === c ? B.ink : "transparent", color: cat === c ? B.cream : B.ink,
                border: `1.5px solid ${cat === c ? B.ink : B.ink + "44"}`,
                fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "inherit",
              }}>{c}</button>
            ))}
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 24 }}>
          {shown.map((p, i) => <ProductCardB key={p.id} p={p} i={i} onAdd={onAdd} />)}
        </div>
      </div>
    </section>
  );
};

const ProductCardB = ({ p, i, onAdd }) => {
  const [ref, v] = useRevealB();
  const [hover, setHover] = uB(false);
  const [added, setAdded] = uB(false);
  const handle = () => { onAdd(p); setAdded(true); setTimeout(() => setAdded(false), 1200); };
  return (
    <div ref={ref} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: B.cream, borderRadius: 2,
        opacity: v ? 1 : 0, transform: v ? "translateY(0)" : "translateY(20px)",
        transition: `all .5s ${i * 0.04}s`,
      }}>
      <div style={{
        aspectRatio: "1", background: p.colore,
        display: "grid", placeItems: "center", fontSize: 90,
        overflow: "hidden", position: "relative",
      }}>
        <div style={{ transform: hover ? "scale(1.15) rotate(-6deg)" : "scale(1)", transition: "transform .4s" }}>{p.emoji}</div>
        {p.offerta && (
          <div style={{ position: "absolute", top: 12, left: 12, background: B.accent, color: B.cream, fontSize: 11, padding: "4px 10px", borderRadius: 99, fontWeight: 700, letterSpacing: "0.1em" }}>IN OFFERTA</div>
        )}
      </div>
      <div style={{ padding: "16px 4px" }}>
        <div style={{ fontSize: 11, color: B.blue, letterSpacing: "0.15em", fontWeight: 600, textTransform: "uppercase" }}>{p.cat}</div>
        <h4 style={{ margin: "6px 0 10px", fontSize: 17, color: B.ink, fontFamily: "'Fraunces', serif", fontWeight: 500, lineHeight: 1.3 }}>{p.nome}</h4>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            {p.prezzoVecchio && <span style={{ textDecoration: "line-through", opacity: 0.4, fontSize: 13, marginRight: 6, color: B.ink }}>€{p.prezzoVecchio.toFixed(2)}</span>}
            <span style={{ fontSize: 20, fontWeight: 700, color: B.ink, fontFamily: "'Fraunces', serif" }}>€{p.prezzo.toFixed(2)}</span>
          </div>
          <button onClick={handle} style={{
            background: added ? B.blue : B.ink, color: B.cream,
            border: "none", width: 38, height: 38, borderRadius: "50%",
            cursor: "pointer", display: "grid", placeItems: "center", transition: "all .2s",
          }}>
            {added ? <Icon name="check" size={16} stroke={B.cream} /> : <Icon name="plus" size={16} stroke={B.cream} />}
          </button>
        </div>
      </div>
    </div>
  );
};

window.B = B;
window.useRevealB = useRevealB;
window.HeaderB = HeaderB;
window.HeroB = HeroB;
window.ServiziB = ServiziB;
window.StoriaB = StoriaB;
window.ShopB = ShopB;

// Direction C — BOTTEGA DI QUARTIERE, giocosa, illustrata
// Palette: giallo caldo + blu cobalto + rosso pomodoro, tratti disegnati, sticker vibes
// Interazioni: tool che ballano, sticker rotanti al hover, carosello manuale, testo "handwritten"

const { useState: uC, useEffect: eC, useRef: rC, useMemo: mC } = React;

const C = {
  yellow: "#FFCC29",
  yellowDark: "#F2A900",
  blue: "#1744B4",
  blueDark: "#0A2875",
  red: "#E63946",
  green: "#2A9D8F",
  cream: "#FFF5DC",
  paper: "#FDF8E8",
  ink: "#1A1410",
};

const useRevealC = () => {
  const ref = rC(null);
  const [v, setV] = uC(false);
  eC(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setV(true); io.disconnect(); }}, { threshold: 0.15 });
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return [ref, v];
};

// Sticker wrapper
const Sticker = ({ children, rot = 0, color = C.yellow, size }) => (
  <div style={{
    display: "inline-grid", placeItems: "center",
    width: size, height: size, background: color,
    borderRadius: "50%", border: `3px solid ${C.ink}`,
    transform: `rotate(${rot}deg)`,
    boxShadow: `3px 4px 0 ${C.ink}`,
  }}>{children}</div>
);

// ── Header: flat colorful top bar
const HeaderC = ({ onCart, count }) => {
  const links = [["Reparti","#serv-c"],["Shop","#shop-c"],["Storia","#chi-c"],["Recensioni","#rec-c"],["Dove","#dove-c"]];
  return (
    <>
      {/* Top strip */}
      <div style={{ background: C.blue, color: C.yellow, fontSize: 13, padding: "8px 0", textAlign: "center", fontWeight: 700, letterSpacing: "0.05em" }}>
        ☎ 011 353934 · ⏱ Aperto oggi 9-12:30 / 15:30-19:00 · 📍 Via Graglia 6, Torino
      </div>
      <header style={{ position: "sticky", top: 0, zIndex: 100, background: C.yellow, borderBottom: `3px solid ${C.ink}` }}>
        <div style={{ maxWidth: 1400, margin: "0 auto", padding: "14px 28px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24 }}>
          <a href="#top-c" style={{ textDecoration: "none", color: C.blue, display: "flex", alignItems: "center", gap: 12 }}>
            <img src="assets/logo-aruga-crop.png" alt="Ferramenta Aruga" style={{ height: 80, width: "auto", display: "block" }} />
          </a>
          <nav style={{ display: "flex", gap: 4 }}>
            {links.map(([l,h]) => (
              <a key={h} href={h} style={{ padding: "8px 14px", color: C.blue, textDecoration: "none", fontWeight: 800, fontSize: 14, borderRadius: 99, transition: "all .15s" }}
                onMouseEnter={e => { e.currentTarget.style.background = C.blue; e.currentTarget.style.color = C.yellow; }}
                onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = C.blue; }}>{l}</a>
            ))}
          </nav>
          <button onClick={onCart} style={{ background: C.red, color: "#fff", border: `3px solid ${C.ink}`, padding: "10px 18px", borderRadius: 99, fontWeight: 900, fontSize: 14, cursor: "pointer", display: "flex", alignItems: "center", gap: 8, fontFamily: "inherit", boxShadow: `3px 3px 0 ${C.ink}` }}>
            <Icon name="cart" size={18} stroke="#fff" /> {count > 0 && <span>{count}</span>}
          </button>
        </div>
      </header>
    </>
  );
};

// ── Hero
const HeroC = () => {
  const [y, setY] = uC(0);
  eC(() => { const h = () => setY(window.scrollY); window.addEventListener("scroll", h, { passive: true }); return () => window.removeEventListener("scroll", h); }, []);
  const danceTools = [
    { name: "hammer", color: C.red, top: "15%", left: "5%", dur: 3, rot: -20 },
    { name: "drill", color: C.blue, top: "12%", right: "8%", dur: 4, rot: 15 },
    { name: "key", color: C.green, bottom: "22%", left: "10%", dur: 3.5, rot: 30 },
    { name: "wrench", color: C.yellowDark, bottom: "28%", right: "6%", dur: 3.2, rot: -15 },
    { name: "bulb", color: C.red, top: "45%", left: "2%", dur: 2.8, rot: 8 },
    { name: "paint", color: C.blue, top: "55%", right: "3%", dur: 3.6, rot: -25 },
  ];
  return (
    <section id="top-c" style={{ position: "relative", minHeight: "100vh", background: C.yellow, overflow: "hidden" }}>
      {/* polka dots bg */}
      <div style={{ position: "absolute", inset: 0, backgroundImage: `radial-gradient(circle, ${C.ink}11 2px, transparent 2px)`, backgroundSize: "40px 40px" }} />
      {/* dancing tools */}
      {danceTools.map((t, i) => (
        <div key={i} style={{ position: "absolute", ...t, animation: `bobC${i % 3} ${t.dur}s ease-in-out infinite`, transform: `rotate(${t.rot}deg)` }}>
          <div style={{ width: 90, height: 90, background: t.color, border: `3px solid ${C.ink}`, borderRadius: "50%", display: "grid", placeItems: "center", boxShadow: `4px 5px 0 ${C.ink}` }}>
            <Icon name={t.name} size={44} stroke={C.yellow} sw={2.5} />
          </div>
        </div>
      ))}

      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "80px 28px", position: "relative", zIndex: 2, minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ display: "inline-block", background: C.red, color: "#fff", padding: "8px 20px", borderRadius: 99, fontWeight: 900, fontSize: 14, border: `2.5px solid ${C.ink}`, transform: "rotate(-2deg)", boxShadow: `3px 3px 0 ${C.ink}`, marginBottom: 30 }}>
            ✦ Una bottega, mille soluzioni ✦
          </div>
          <h1 style={{
            fontSize: "clamp(70px, 12vw, 200px)",
            fontFamily: "'Rubik', 'Archivo Black', sans-serif",
            fontWeight: 900,
            color: C.blue,
            lineHeight: 0.85,
            letterSpacing: "-0.04em",
            margin: 0,
            WebkitTextStroke: `3px ${C.ink}`,
            textShadow: `6px 6px 0 ${C.red}, 6px 6px 0 3px ${C.ink}`,
          }}>
            Se serve,<br/>ce l'abbiamo.
          </h1>
          <p style={{ fontSize: 22, color: C.ink, maxWidth: 680, margin: "40px auto 0", lineHeight: 1.45, fontWeight: 500 }}>
            Da quasi <b>quarant'anni</b>, in <span style={{ background: "#fff", padding: "2px 8px", border: `2px solid ${C.ink}`, boxShadow: `2px 2px 0 ${C.ink}`, display: "inline-block" }}>via Graglia 6</span>, siamo il negozio di ferramenta del quartiere.
            Utensili, vernici, chiavi, consigli. Un posto dove <b>si risponde — non si rimanda</b>.
          </p>
          <div style={{ marginTop: 40, display: "flex", gap: 16, flexWrap: "wrap", justifyContent: "center" }}>
            <a href="#dove-c" style={btnC(C.red, "#fff")}>
              <Icon name="pin" size={18} stroke="#fff" /> VIENI IN BOTTEGA
            </a>
            <a href="#shop-c" style={btnC(C.blue, C.yellow)}>
              <Icon name="cart" size={18} stroke={C.yellow} /> VEDI LO SHOP
            </a>
          </div>
        </div>

        {/* logo float */}
        <div style={{ marginTop: 60, display: "flex", justifyContent: "center" }}>
          <div style={{
            width: 200, height: 200, borderRadius: "50%",
            border: `5px solid ${C.ink}`, background: C.yellow,
            boxShadow: `8px 8px 0 ${C.ink}`,
            overflow: "hidden",
            transform: `rotate(${y * 0.05}deg)`,
            transition: "transform .3s",
          }}>
            <img src="assets/logo-aruga.jpeg" alt="Aruga" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
        </div>
      </div>
    </section>
  );
};

const btnC = (bg, fg) => ({
  display: "inline-flex", alignItems: "center", gap: 10,
  background: bg, color: fg, padding: "18px 28px",
  borderRadius: 99, border: `3px solid ${C.ink}`,
  fontWeight: 900, fontSize: 15, textDecoration: "none",
  boxShadow: `5px 5px 0 ${C.ink}`,
  letterSpacing: "0.05em",
  transition: "transform .12s, box-shadow .12s",
});

// ── Servizi — sticker bubbles in a playful grid
const ServiziC = () => {
  const [ref, v] = useRevealC();
  const palette = [C.red, C.blue, C.green, C.yellowDark, C.blue, C.red, C.green, C.yellowDark, C.red, C.blue, C.green];
  return (
    <section id="serv-c" style={{ background: C.paper, padding: "120px 0", position: "relative", overflow: "hidden" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <div style={{ display: "inline-block", background: C.yellow, padding: "6px 16px", borderRadius: 99, fontWeight: 900, border: `2px solid ${C.ink}`, transform: "rotate(-1deg)", fontSize: 12, letterSpacing: "0.15em" }}>I NOSTRI REPARTI</div>
          <h2 style={{ fontSize: "clamp(44px, 7vw, 88px)", fontFamily: "'Rubik', 'Archivo Black', sans-serif", fontWeight: 900, color: C.blue, letterSpacing: "-0.03em", lineHeight: 1, margin: "20px 0 16px" }}>
            Entri, chiedi, <span style={{ color: C.red, fontStyle: "italic" }}>risolvi.</span>
          </h2>
          <p style={{ fontSize: 18, color: C.ink, maxWidth: 580, margin: "0 auto", opacity: 0.8 }}>
            Undici reparti per tutto quello che serve in casa, in giardino, a lavoro. E se qualcosa manca — lo troviamo.
          </p>
        </div>
        <div ref={ref} style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20 }}>
          {SERVIZI.map((s, i) => <ServiceStickerC key={s.id} s={s} i={i} v={v} color={palette[i]} />)}
        </div>
      </div>
    </section>
  );
};

const ServiceStickerC = ({ s, i, v, color }) => {
  const [hover, setHover] = uC(false);
  const rot = (i % 2 === 0 ? 1 : -1) * (1 + (i % 3));
  const isDark = color === C.blue || color === C.red || color === C.green;
  const fg = isDark ? "#fff" : C.ink;
  return (
    <div
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: color, color: fg,
        border: `3px solid ${C.ink}`, borderRadius: 28,
        padding: 22, position: "relative",
        transform: v ? `rotate(${hover ? 0 : rot}deg) translateY(${hover ? -6 : 0}px)` : "translateY(30px) rotate(0)",
        opacity: v ? 1 : 0,
        boxShadow: hover ? `10px 10px 0 ${C.ink}` : `5px 5px 0 ${C.ink}`,
        transition: `all .4s ${i * 0.04}s`,
        cursor: "pointer",
    }}>
      <div style={{
        position: "absolute", top: -18, right: 16,
        width: 40, height: 40, background: C.yellow, color: C.ink,
        borderRadius: "50%", border: `2.5px solid ${C.ink}`, display: "grid", placeItems: "center",
        fontWeight: 900, fontSize: 14, fontFamily: "'Rubik', sans-serif",
        transform: "rotate(-8deg)",
      }}>{String(i+1).padStart(2, "0")}</div>
      <div style={{ width: 60, height: 60, background: isDark ? C.yellow : "#fff", border: `2.5px solid ${C.ink}`, borderRadius: 16, display: "grid", placeItems: "center", marginBottom: 14, transform: hover ? "rotate(-6deg) scale(1.1)" : "rotate(0)", transition: "transform .3s" }}>
        <Icon name={s.icon} size={32} stroke={isDark ? C.blue : C.blue} sw={2.5} />
      </div>
      <h3 style={{ fontSize: 22, margin: "0 0 8px", fontWeight: 900, letterSpacing: "-0.02em" }}>{s.titolo}</h3>
      <p style={{ fontSize: 14, margin: 0, lineHeight: 1.5, opacity: 0.9 }}>{s.desc}</p>
    </div>
  );
};

window.C = C;
window.useRevealC = useRevealC;
window.HeaderC = HeaderC;
window.HeroC = HeroC;
window.ServiziC = ServiziC;
window.btnC = btnC;
window.Sticker = Sticker;

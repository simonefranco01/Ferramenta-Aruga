// Shared data for all three site directions
const CONTATTI = {
  nome: "Ferramenta Aruga",
  dal: "1986",
  indirizzo: "Via Graglia, 6",
  citta: "10136 Torino",
  telefono: "011 353934",
  telefonoHref: "tel:+390113539340",
  orari: [
    { g: "Lunedì", h: "09:00 – 12:30 · 15:30 – 19:00" },
    { g: "Martedì", h: "09:00 – 12:30 · 15:30 – 19:00" },
    { g: "Mercoledì", h: "09:00 – 12:30 · 15:30 – 19:00" },
    { g: "Giovedì", h: "09:00 – 12:30 · 15:30 – 19:00" },
    { g: "Venerdì", h: "09:00 – 12:30 · 15:30 – 19:00" },
    { g: "Sabato", h: "09:00 – 12:30" },
    { g: "Domenica", h: "Chiuso" },
  ],
};

const SERVIZI = [
  { id: "utensili", titolo: "Utensili e attrezzi", desc: "Dalla chiave inglese al set professionale: marche selezionate, consigli inclusi.", icon: "hammer" },
  { id: "elettro", titolo: "Elettroutensili", desc: "Trapani, avvitatori, levigatrici. Le migliori marche, garantite.", icon: "drill" },
  { id: "idraulica", titolo: "Idraulica", desc: "Raccordi, tubi, guarnizioni. Risolviamo la perdita prima che diventi disastro.", icon: "pipe" },
  { id: "elettricita", titolo: "Elettricità & Illuminazione", desc: "Cavi, interruttori, lampadine LED. Luce giusta, ovunque.", icon: "bulb" },
  { id: "chiavi", titolo: "Duplicazione chiavi", desc: "Chiavi comuni, di sicurezza, telecomandi cancello. Pronte in pochi minuti.", icon: "key" },
  { id: "vernici", titolo: "Vernici & Pittura", desc: "Smalti, idropitture, colorazione su richiesta. Il colore giusto per ogni parete.", icon: "paint" },
  { id: "giardino", titolo: "Giardinaggio", desc: "Forbici, terricci, irrigazione. Per balconi, orti e giardini.", icon: "leaf" },
  { id: "casa", titolo: "Casalinghi", desc: "Tutto il necessario per la casa, scelto con cura.", icon: "home" },
  { id: "bulloneria", titolo: "Bulloneria & Minuteria", desc: "Viti, bulloni, rondelle: in confezione o al pezzo.", icon: "bolt" },
  { id: "riparazioni", titolo: "Riparazioni a domicilio", desc: "Installazioni e piccole riparazioni direttamente a casa tua (in zona).", icon: "wrench" },
  { id: "consulenza", titolo: "Consulenza fai-da-te", desc: "Non sai da dove iniziare? Ti guidiamo noi, passo per passo.", icon: "chat" },
];

const RECENSIONI = [
  { nome: "Filippo Gabetta", quando: "2 mesi fa", stelle: 5, testo: "Gentile, professionale: lunga vita ad attività come queste." },
  { nome: "Massimo Penasso", quando: "8 mesi fa", stelle: 5, testo: "Ottima professionalità e onestà. Trovi tutto quello che cerchi. Torno tutte le volte che ho un problema." },
  { nome: "Stefano Macario", quando: "5 mesi fa", stelle: 5, testo: "Ottima ferramenta, titolari gentili, ben fornita." },
  { nome: "Stefano Tavernese", quando: "7 anni fa", stelle: 5, testo: "Si trova di tutto e, a differenza dei grossi centri fai da te, sanno fornire indicazioni su quale prodotto e come sia meglio utilizzarlo. Forniscono anche supporto per installazioni e riparazioni a domicilio. Consigliato." },
  { nome: "Angelo C.", quando: "5 anni fa", stelle: 5, testo: "Robi & Robi che squadra! Hanno sempre una soluzione per il cliente e quando non ce l'hanno la inventano nel loro retrobottega! Preparati, gentili e disponibili. La mia ferramenta di fiducia da 3 anni." },
  { nome: "Andre Santos", quando: "2 anni fa", stelle: 5, testo: "L'unico negozio di ferramenta vero nel raggio di 1km." },
  { nome: "Claudio Sard", quando: "1 anno fa", stelle: 5, testo: "Ormai sono anni che mi rivolgo a loro per tanti motivi e mi trovo sempre soddisfatto." },
  { nome: "Angela Anna Santoro", quando: "6 anni fa", stelle: 5, testo: "Ferramenta molto fornita, simpatia e disponibilità dei gestori che spesso danno anche utili consigli. Vendita anche di articoli per pitturazione e oggetti indispensabili per la casa." },
  { nome: "Federica F.", quando: "5 anni fa", stelle: 5, testo: "Il negozio di ferramenta di fiducia! Il proprietario è di una gentilezza, disponibilità e professionalità più uniche che rare. Prezzi competitivi e tanta scelta. Consigliatissimo!" },
  { nome: "Richi M.", quando: "6 anni fa", stelle: 5, testo: "Ottimo negozio ben fornito. Personale gentile, fornisce sempre consigli utili. Mi servo da loro da moltissimi anni." },
  { nome: "Ermanno M. Bacchetta", quando: "1 anno fa", stelle: 5, testo: "Sempre presente negli orari, ti serve subito senza problemi." },
  { nome: "Roberto Guerra", quando: "4 anni fa", stelle: 5, testo: "Gentilissimi, ben forniti e prezzi giusti: fossero tutti così!" },
  { nome: "Luca Zocca", quando: "5 anni fa", stelle: 5, testo: "Come i negozi di una volta. Non è grandissimo ma dentro trovi di tutto." },
  { nome: "Ferruccio Piano", quando: "5 anni fa", stelle: 5, testo: "Una buona ferramenta ben fornita, ottimo servizio." },
  { nome: "Omero Badiali", quando: "6 anni fa", stelle: 5, testo: "Comoda per chi abita nei dintorni, molto fornita, gestori disponibili e simpatici." },
  { nome: "Jonathan Catalano", quando: "4 anni fa", stelle: 5, testo: "Viva la ferramenta, abbasso i supermercati-ferramenta." },
  { nome: "Er Biscione", quando: "1 anno fa", stelle: 5, testo: "Davvero super top." },
];

// Products for the e-commerce mock
const PRODOTTI = [
  { id: "p1", nome: "Martello carpentiere 500g", cat: "Utensili", prezzo: 18.90, emoji: "🔨", colore: "#FFD60A" },
  { id: "p2", nome: "Trapano avvitatore 18V", cat: "Elettroutensili", prezzo: 129.00, emoji: "🪛", colore: "#1E40AF", offerta: true, prezzoVecchio: 159.00 },
  { id: "p3", nome: "Set cacciaviti 6 pezzi", cat: "Utensili", prezzo: 14.50, emoji: "🔧", colore: "#FFD60A" },
  { id: "p4", nome: "Pittura murale bianca 5L", cat: "Vernici", prezzo: 24.00, emoji: "🎨", colore: "#FFFFFF" },
  { id: "p5", nome: "Chiave a brugola set", cat: "Utensili", prezzo: 9.80, emoji: "🗝️", colore: "#FFD60A" },
  { id: "p6", nome: "Serratura di sicurezza", cat: "Serrature", prezzo: 45.00, emoji: "🔐", colore: "#1E40AF" },
  { id: "p7", nome: "Lampadina LED E27 12W", cat: "Elettricità", prezzo: 4.90, emoji: "💡", colore: "#FFD60A" },
  { id: "p8", nome: "Guanti da lavoro", cat: "Sicurezza", prezzo: 6.50, emoji: "🧤", colore: "#1E40AF" },
  { id: "p9", nome: "Tubo giardino 20m", cat: "Giardinaggio", prezzo: 32.00, emoji: "🌿", colore: "#16A34A", offerta: true, prezzoVecchio: 39.00 },
  { id: "p10", nome: "Viti legno 4x40 (100pz)", cat: "Bulloneria", prezzo: 3.20, emoji: "⚙️", colore: "#1E40AF" },
  { id: "p11", nome: "Nastro americano 50m", cat: "Utensili", prezzo: 5.50, emoji: "📏", colore: "#FFD60A" },
  { id: "p12", nome: "Forbici da potatura", cat: "Giardinaggio", prezzo: 18.00, emoji: "✂️", colore: "#16A34A" },
];

window.CONTATTI = CONTATTI;
window.SERVIZI = SERVIZI;
window.RECENSIONI = RECENSIONI;
window.PRODOTTI = PRODOTTI;

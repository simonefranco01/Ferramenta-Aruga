// Direction A — POP INDUSTRIALE
// Giallo acceso + blu cobalto, grid segnaletica, tipografia grassa, tutto con bordi spessi neri
// Animazioni: scroll reveal, parallax tools fluttuanti, recensioni marquee, typewriter claim

const { useState, useEffect, useRef, useMemo } = React;

// ────────────────────────────────────────────────────────────
// Hooks
const useInView = (opts = {}) => {
  const ref = useRef(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setInView(true); io.disconnect(); }
    }, { threshold: 0.15, ...opts });
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return [ref, inView];
};

const useScrollY = () => {
  const [y, setY] = useState(0);
  useEffect(() => {
    const onScroll = () => setY(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return y;
};

// ────────────────────────────────────────────────────────────
// Palette + constants
const A = {
  yellow: "#FFD60A",
  yellowDeep: "#F5B700",
  blue: "#1E3A8A",
  blueDeep: "#0F1E5C",
  black: "#0A0A0A",
  cream: "#FFF8E5",
  red: "#E63946",
  green: "#2A9D8F",
};

// ────────────────────────────────────────────────────────────
// Typewriter
const Typewriter = ({ words, speed = 90, pause = 1400 }) => {
  const [idx, setIdx] = useState(0);
  const [sub, setSub] = useState(0);
  const [deleting, setDeleting] = useState(false);
  useEffect(() => {
    const w = words[idx];
    if (!deleting && sub === w.length) {
      const t = setTimeout(() => setDeleting(true), pause);
      return () => clearTimeout(t);
    }
    if (deleting && sub === 0) {
      setDeleting(false);
      setIdx((idx + 1) % words.length);
      return;
    }
    const t = setTimeout(() => setSub(sub + (deleting ? -1 : 1)), deleting ? speed / 2 : speed);
    return () => clearTimeout(t);
  }, [sub, deleting, idx]);
  return (
    <span style={{ color: A.yellow, background: A.blue, padding: "0 12px", whiteSpace: "nowrap" }}>
      {words[idx].slice(0, sub)}
      <span style={{ display: "inline-block", width: 3, height: "0.9em", background: A.yellow, verticalAlign: "middle", marginLeft: 4, animation: "blink 1s infinite" }} />
    </span>
  );
};

// ────────────────────────────────────────────────────────────
// Floating tools parallax
const FloatingTools = ({ y }) => {
  const tools = ["hammer", "drill", "bolt", "wrench", "paint", "key", "bulb"];
  return (
    <div style={{ position: "absolute", inset: 0, pointerEvents: "none", overflow: "hidden" }}>
      {tools.map((t, i) => {
        const seed = i * 137;
        const left = (seed * 1.3) % 90 + 5;
        const top = (seed * 0.7) % 85 + 5;
        const speed = 0.15 + (i % 3) * 0.1;
        const rot = (y * 0.1 + i * 40) % 360;
        return (
          <div key={i} style={{
            position: "absolute",
            left: `${left}%`, top: `${top}%`,
            transform: `translateY(${-y * speed}px) rotate(${rot}deg)`,
            opacity: 0.12,
            color: A.blue,
          }}>
            <Icon name={t} size={60 + (i % 3) * 20} sw={2.5} />
          </div>
        );
      })}
    </div>
  );
};

// ────────────────────────────────────────────────────────────
// Header / Nav
const HeaderA = ({ onCart, cartCount }) => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const links = [
    ["Servizi", "#servizi"],
    ["Shop", "#shop"],
    ["Chi siamo", "#chi"],
    ["Recensioni", "#recensioni"],
    ["Dove siamo", "#dove"],
    ["Contatti", "#contatti"],
  ];
  return (
    <header style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
      background: scrolled ? A.yellow : "transparent",
      borderBottom: scrolled ? `3px solid ${A.black}` : "3px solid transparent",
      transition: "all .3s",
    }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "14px 28px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24 }}>
        <a href="#top" style={{ display: "flex", alignItems: "center", gap: 10, textDecoration: "none", color: A.blue, fontWeight: 900, fontSize: 20, letterSpacing: "-0.02em" }}>
          <span style={{ width: 40, height: 40, background: A.blue, color: A.yellow, display: "grid", placeItems: "center", border: `2px solid ${A.black}`, boxShadow: `3px 3px 0 ${A.black}` }}>
            <Icon name="hammer" size={24} stroke={A.yellow} sw={2.5} />
          </span>
          <span>ARUGA<span style={{ color: A.red, fontSize: 12, marginLeft: 6, verticalAlign: "super" }}>dal '86</span></span>
        </a>
        <nav style={{ display: "flex", gap: 4 }}>
          {links.map(([l, h]) => (
            <a key={h} href={h} style={{
              padding: "8px 14px",
              color: A.blue, textDecoration: "none", fontWeight: 700, fontSize: 14,
              border: "2px solid transparent", transition: "all .15s",
              textTransform: "uppercase", letterSpacing: "0.03em",
            }}
            onMouseEnter={e => { e.currentTarget.style.background = A.blue; e.currentTarget.style.color = A.yellow; e.currentTarget.style.border = `2px solid ${A.black}`; }}
            onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = A.blue; e.currentTarget.style.border = "2px solid transparent"; }}
            >{l}</a>
          ))}
        </nav>
        <button onClick={onCart} style={{
          background: A.blue, color: A.yellow, border: `2px solid ${A.black}`,
          boxShadow: `4px 4px 0 ${A.black}`,
          padding: "10px 18px", fontWeight: 900, fontSize: 14,
          display: "flex", alignItems: "center", gap: 8,
          cursor: "pointer", fontFamily: "inherit",
          transition: "transform .12s, box-shadow .12s",
        }}
        onMouseDown={e => { e.currentTarget.style.transform = "translate(3px,3px)"; e.currentTarget.style.boxShadow = `1px 1px 0 ${A.black}`; }}
        onMouseUp={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = `4px 4px 0 ${A.black}`; }}
        onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = `4px 4px 0 ${A.black}`; }}
        >
          <Icon name="cart" size={18} stroke={A.yellow} />
          CARRELLO
          {cartCount > 0 && <span style={{ background: A.red, color: "#fff", borderRadius: 99, padding: "1px 7px", fontSize: 12 }}>{cartCount}</span>}
        </button>
      </div>
    </header>
  );
};

// ────────────────────────────────────────────────────────────
// Hero
const HeroA = () => {
  const y = useScrollY();
  return (
    <section id="top" style={{
      position: "relative", minHeight: "100vh",
      background: A.yellow,
      overflow: "hidden",
      paddingTop: 120,
      paddingBottom: 80,
    }}>
      <FloatingTools y={y} />
      {/* Diagonal stripes */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `repeating-linear-gradient(135deg, transparent 0 60px, ${A.yellowDeep}33 60px 62px)`,
        pointerEvents: "none",
      }} />
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px", position: "relative", zIndex: 2 }}>
        {/* Top badge row */}
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 48 }}>
          <span style={{ background: A.black, color: A.yellow, padding: "8px 16px", fontWeight: 800, fontSize: 13, letterSpacing: "0.1em" }}>◉ APERTO ORA — CHIUDE ALLE 19:00</span>
          <span style={{ background: A.red, color: "#fff", padding: "8px 16px", fontWeight: 800, fontSize: 13, letterSpacing: "0.1em" }}>★ 4.9 / 5 SU GOOGLE</span>
          <span style={{ background: A.blue, color: A.yellow, padding: "8px 16px", fontWeight: 800, fontSize: 13, letterSpacing: "0.1em" }}>↳ VIA GRAGLIA 6, TORINO</span>
        </div>

        {/* Big logo / title */}
        <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 60, alignItems: "center" }}>
          <div>
            <h1 style={{
              fontSize: "clamp(60px, 10vw, 160px)",
              fontWeight: 900,
              lineHeight: 0.85,
              color: A.blue,
              margin: 0,
              letterSpacing: "-0.04em",
              fontFamily: "'Archivo Black', Impact, sans-serif",
            }}>
              FERRA-<br/>MENTA<br/>
              <span style={{ color: A.blue, WebkitTextStroke: `3px ${A.black}` }}>ARUGA</span>
            </h1>
            <div style={{ marginTop: 24, fontSize: 24, fontWeight: 700, color: A.black }}>
              La tua bottega di fiducia, <Typewriter words={["dal 1986.", "a Torino.", "per ogni fai-da-te.", "quando serve."]} />
            </div>
            <p style={{ marginTop: 24, fontSize: 18, color: A.black, maxWidth: 520, lineHeight: 1.5 }}>
              Un vero negozio di quartiere dove trovi tutto, ti danno consigli veri, e se la soluzione non esiste — <b>la inventano nel retrobottega</b>.
            </p>
            <div style={{ marginTop: 32, display: "flex", gap: 14, flexWrap: "wrap" }}>
              <a href="#dove" style={btnA(A.blue, A.yellow)}>
                <Icon name="pin" size={18} stroke={A.yellow} /> VIENI A TROVARCI
              </a>
              <a href="#shop" style={btnA("#fff", A.blue)}>
                <Icon name="cart" size={18} stroke={A.blue} /> GUARDA LO SHOP
              </a>
            </div>
          </div>
          {/* Logo mark */}
          <div style={{
            position: "relative", aspectRatio: "1", maxWidth: 440, margin: "0 auto",
            border: `4px solid ${A.black}`, background: A.yellow,
            boxShadow: `12px 12px 0 ${A.black}`,
            display: "grid", placeItems: "center",
            transform: "rotate(-2deg)",
          }}>
            <img src="assets/logo-aruga.jpeg" alt="Ferramenta Aruga" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            <span style={{
              position: "absolute", top: -20, right: -20,
              background: A.red, color: "#fff",
              width: 110, height: 110, borderRadius: "50%",
              display: "grid", placeItems: "center", textAlign: "center",
              fontWeight: 900, fontSize: 14, lineHeight: 1.1,
              border: `3px solid ${A.black}`, transform: "rotate(12deg)",
              boxShadow: `4px 4px 0 ${A.black}`,
            }}>40<br/>ANNI<br/>DI MESTIERE</span>
          </div>
        </div>

        {/* Ticker / strip */}
        <div style={{
          marginTop: 60, background: A.black, color: A.yellow,
          padding: "14px 0", overflow: "hidden", display: "flex", gap: 40,
          border: `3px solid ${A.black}`,
        }}>
          <div style={{ display: "flex", gap: 40, animation: "scroll-left 30s linear infinite", whiteSpace: "nowrap", paddingLeft: 40 }}>
            {Array.from({ length: 4 }).map((_, k) => (
              <React.Fragment key={k}>
                <span style={{ fontWeight: 900, fontSize: 20 }}>▲ UTENSILI</span>
                <span style={{ fontWeight: 900, fontSize: 20 }}>● ELETTROUTENSILI</span>
                <span style={{ fontWeight: 900, fontSize: 20 }}>◆ IDRAULICA</span>
                <span style={{ fontWeight: 900, fontSize: 20 }}>■ VERNICI</span>
                <span style={{ fontWeight: 900, fontSize: 20 }}>★ DUPLICAZIONE CHIAVI</span>
                <span style={{ fontWeight: 900, fontSize: 20 }}>▲ GIARDINAGGIO</span>
                <span style={{ fontWeight: 900, fontSize: 20 }}>● BULLONERIA</span>
                <span style={{ fontWeight: 900, fontSize: 20 }}>◆ RIPARAZIONI A DOMICILIO</span>
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const btnA = (bg, fg) => ({
  display: "inline-flex", alignItems: "center", gap: 10,
  background: bg, color: fg,
  border: `3px solid ${A.black}`,
  boxShadow: `6px 6px 0 ${A.black}`,
  padding: "16px 26px", fontWeight: 900, fontSize: 16,
  textDecoration: "none", cursor: "pointer", fontFamily: "inherit",
  letterSpacing: "0.05em",
  transition: "transform .12s, box-shadow .12s",
});

// ────────────────────────────────────────────────────────────
// Servizi grid
const ServiziA = () => {
  return (
    <section id="servizi" style={{ background: A.cream, padding: "100px 0", position: "relative" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px" }}>
        <SectionHeaderA kicker="01 / Cosa facciamo" title="COSA TROVI DA NOI" />
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: 16, marginTop: 60,
        }}>
          {SERVIZI.map((s, i) => <ServiceCardA key={s.id} s={s} i={i} />)}
        </div>
      </div>
    </section>
  );
};

const SectionHeaderA = ({ kicker, title, dark }) => {
  const [ref, inView] = useInView();
  return (
    <div ref={ref} style={{
      borderLeft: `6px solid ${A.blue}`,
      paddingLeft: 20,
      opacity: inView ? 1 : 0,
      transform: inView ? "translateX(0)" : "translateX(-40px)",
      transition: "all .6s",
    }}>
      <div style={{ fontSize: 14, fontWeight: 800, color: A.red, letterSpacing: "0.15em", textTransform: "uppercase" }}>{kicker}</div>
      <h2 style={{
        fontSize: "clamp(40px, 6vw, 80px)",
        fontWeight: 900, margin: "8px 0 0",
        color: dark ? A.yellow : A.blue,
        letterSpacing: "-0.03em",
        lineHeight: 0.95,
        fontFamily: "'Archivo Black', Impact, sans-serif",
      }}>{title}</h2>
    </div>
  );
};

const ServiceCardA = ({ s, i }) => {
  const [ref, inView] = useInView();
  const [hover, setHover] = useState(false);
  const bg = i % 3 === 0 ? A.yellow : i % 3 === 1 ? "#fff" : A.blue;
  const fg = i % 3 === 2 ? A.yellow : A.blue;
  const txt = i % 3 === 2 ? A.yellow : A.black;
  return (
    <div ref={ref}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: bg, color: txt,
        border: `3px solid ${A.black}`,
        boxShadow: hover ? `10px 10px 0 ${A.black}` : `5px 5px 0 ${A.black}`,
        padding: 24,
        opacity: inView ? 1 : 0,
        transform: inView
          ? (hover ? "translate(-5px,-5px)" : "translate(0,0)")
          : "translateY(40px)",
        transition: `opacity .6s ${i * 0.04}s, transform .2s, box-shadow .2s`,
        position: "relative",
        overflow: "hidden",
      }}>
      <div style={{ width: 56, height: 56, background: fg, color: i % 3 === 2 ? A.blue : A.yellow, display: "grid", placeItems: "center", border: `2px solid ${A.black}`, marginBottom: 16 }}>
        <Icon name={s.icon} size={32} stroke={i % 3 === 2 ? A.blue : A.yellow} sw={2.5} />
      </div>
      <div style={{ fontSize: 12, fontWeight: 800, opacity: 0.6, letterSpacing: "0.1em" }}>N° {String(i + 1).padStart(2, "0")}</div>
      <h3 style={{ fontSize: 22, fontWeight: 900, margin: "4px 0 10px", letterSpacing: "-0.02em" }}>{s.titolo}</h3>
      <p style={{ fontSize: 14, lineHeight: 1.5, margin: 0, opacity: 0.9 }}>{s.desc}</p>
    </div>
  );
};

// ────────────────────────────────────────────────────────────
// Chi siamo — with big stats
const ChiSiamoA = () => {
  const [ref, inView] = useInView();
  return (
    <section id="chi" style={{
      background: A.blue, color: A.yellow,
      padding: "100px 0", position: "relative", overflow: "hidden",
    }}>
      {/* bg pattern */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `radial-gradient(circle, ${A.yellow}22 1px, transparent 1px)`,
        backgroundSize: "24px 24px",
      }} />
      <div ref={ref} style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px", position: "relative" }}>
        <SectionHeaderA kicker="02 / Chi siamo" title="UNA STORIA FATTA DI CHIODI, CHIAVI E CLIENTI." dark />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, marginTop: 60, alignItems: "start" }}>
          <div style={{ fontSize: 20, lineHeight: 1.6, color: "#fff" }}>
            <p style={{ margin: "0 0 20px" }}>
              <b style={{ color: A.yellow }}>Dal 1986 Ferramenta Aruga è in Via Graglia 6</b>, a Torino. Una bottega vera, di quelle che i clienti chiamano "di una volta": piccola fuori, infinita dentro.
            </p>
            <p style={{ margin: "0 0 20px" }}>
              Qui non vendiamo scatole: <b style={{ color: A.yellow }}>risolviamo problemi</b>. Hai una perdita? Una serratura che non gira? Una mensola che non sta su? Vieni, raccontaci e ti diciamo cosa serve — e soprattutto come si fa.
            </p>
            <p style={{ margin: 0 }}>
              E se la soluzione non esiste, la inventiamo nel retrobottega. (Parola di cliente, non nostra.)
            </p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <StatBoxA big="40" sub="anni di attività" note="Dal 1986, senza un giorno di pausa" inView={inView} delay={0.1} />
            <StatBoxA big="11" sub="reparti specializzati" note="Dai trapani alle viti da 3mm" inView={inView} delay={0.2} />
            <StatBoxA big="1000+" sub="prodotti in negozio" note="Se non c'è, lo ordiniamo" inView={inView} delay={0.3} />
            <StatBoxA big="4.9★" sub="voto Google" note="Oltre 60 recensioni positive" inView={inView} delay={0.4} />
          </div>
        </div>
      </div>
    </section>
  );
};

const StatBoxA = ({ big, sub, note, inView, delay }) => (
  <div style={{
    background: A.yellow, color: A.blue,
    border: `3px solid ${A.black}`,
    boxShadow: `6px 6px 0 ${A.black}`,
    padding: 24,
    opacity: inView ? 1 : 0,
    transform: inView ? "translateY(0)" : "translateY(30px)",
    transition: `all .7s ${delay}s`,
  }}>
    <div style={{ fontSize: 56, fontWeight: 900, lineHeight: 1, letterSpacing: "-0.04em", fontFamily: "'Archivo Black', Impact, sans-serif" }}>{big}</div>
    <div style={{ fontSize: 15, fontWeight: 800, marginTop: 4, textTransform: "uppercase" }}>{sub}</div>
    <div style={{ fontSize: 13, opacity: 0.7, marginTop: 6 }}>{note}</div>
  </div>
);

Object.assign(window, {
  useInView, useScrollY, A,
  Typewriter, FloatingTools,
  HeaderA, HeroA, ServiziA, ChiSiamoA,
  SectionHeaderA, btnA,
});

// SVG icon set for tools/services — stroke-based, work in any color
const Icon = ({ name, size = 40, stroke = "currentColor", fill = "none", sw = 2 }) => {
  const common = { width: size, height: size, viewBox: "0 0 48 48", fill, stroke, strokeWidth: sw, strokeLinecap: "round", strokeLinejoin: "round" };
  switch (name) {
    case "hammer":
      return (<svg {...common}><path d="M30 6l12 12-4 4-12-12z"/><path d="M26 10l-4 4 18 18 4-4"/><path d="M22 14L6 30l8 8 16-16"/></svg>);
    case "drill":
      return (<svg {...common}><rect x="6" y="16" width="20" height="14" rx="2"/><path d="M26 20h8v6h-8z"/><path d="M34 23h8"/><path d="M10 30v8h6v-8"/><circle cx="13" cy="23" r="2"/></svg>);
    case "pipe":
      return (<svg {...common}><path d="M6 18h14a6 6 0 016 6v6a6 6 0 006 6h6"/><rect x="4" y="14" width="6" height="8" rx="1"/><rect x="38" y="32" width="6" height="8" rx="1"/></svg>);
    case "bulb":
      return (<svg {...common}><path d="M24 6a12 12 0 00-8 21c2 2 3 4 3 6h10c0-2 1-4 3-6a12 12 0 00-8-21z"/><path d="M19 37h10"/><path d="M20 41h8"/><path d="M24 14v14M20 20l8 8M28 20l-8 8"/></svg>);
    case "key":
      return (<svg {...common}><circle cx="14" cy="24" r="8"/><path d="M22 24h22"/><path d="M38 24v6M32 24v4"/></svg>);
    case "paint":
      return (<svg {...common}><path d="M8 8h28v12H8z"/><path d="M12 20v6a4 4 0 004 4h12a4 4 0 004-4v-2"/><path d="M22 30v8"/><rect x="18" y="38" width="8" height="6" rx="1"/><path d="M36 14h6v6"/></svg>);
    case "leaf":
      return (<svg {...common}><path d="M8 40c0-18 14-32 32-32 0 18-14 32-32 32z"/><path d="M8 40c8-8 16-16 32-32"/></svg>);
    case "home":
      return (<svg {...common}><path d="M6 22L24 6l18 16"/><path d="M10 20v20h28V20"/><path d="M20 40V28h8v12"/></svg>);
    case "bolt":
      return (<svg {...common}><circle cx="24" cy="24" r="6"/><path d="M24 6v6M24 36v6M6 24h6M36 24h6M11 11l4 4M33 33l4 4M11 37l4-4M33 15l4-4"/></svg>);
    case "wrench":
      return (<svg {...common}><path d="M38 10a8 8 0 01-10 10L10 38a4 4 0 01-6-6l18-18A8 8 0 0132 4l-4 4 4 4 4-4z"/></svg>);
    case "chat":
      return (<svg {...common}><path d="M8 10h32a2 2 0 012 2v20a2 2 0 01-2 2H22l-8 8v-8H8a2 2 0 01-2-2V12a2 2 0 012-2z"/><circle cx="18" cy="22" r="1.5" fill={stroke}/><circle cx="24" cy="22" r="1.5" fill={stroke}/><circle cx="30" cy="22" r="1.5" fill={stroke}/></svg>);
    case "star":
      return (<svg {...common} fill={stroke} stroke="none"><path d="M24 4l6 13 14 2-10 10 2 14-12-6-12 6 2-14-10-10 14-2z"/></svg>);
    case "pin":
      return (<svg {...common}><path d="M24 44s14-13 14-24a14 14 0 10-28 0c0 11 14 24 14 24z"/><circle cx="24" cy="20" r="5"/></svg>);
    case "phone":
      return (<svg {...common}><path d="M10 6h8l4 10-6 4c2 6 6 10 12 12l4-6 10 4v8a4 4 0 01-4 4C22 42 6 26 6 10a4 4 0 014-4z"/></svg>);
    case "clock":
      return (<svg {...common}><circle cx="24" cy="24" r="18"/><path d="M24 12v12l8 4"/></svg>);
    case "quote":
      return (<svg {...common} fill={stroke} stroke="none"><path d="M14 10c-5 0-9 4-9 9v17h14V19h-7c0-3 2-5 5-5zM34 10c-5 0-9 4-9 9v17h14V19h-7c0-3 2-5 5-5z"/></svg>);
    case "cart":
      return (<svg {...common}><path d="M6 8h6l4 22h22l4-16H14"/><circle cx="18" cy="38" r="3"/><circle cx="34" cy="38" r="3"/></svg>);
    case "arrow":
      return (<svg {...common}><path d="M8 24h32M28 12l12 12-12 12"/></svg>);
    case "check":
      return (<svg {...common}><path d="M8 24l10 10L40 12"/></svg>);
    case "plus":
      return (<svg {...common}><path d="M24 8v32M8 24h32"/></svg>);
    case "menu":
      return (<svg {...common}><path d="M6 14h36M6 24h36M6 34h36"/></svg>);
    case "close":
      return (<svg {...common}><path d="M10 10l28 28M38 10L10 38"/></svg>);
    case "spark":
      return (<svg {...common}><path d="M24 4v12M24 32v12M4 24h12M32 24h12M10 10l8 8M30 30l8 8M10 38l8-8M30 18l8-8"/></svg>);
    case "instagram":
      return (<svg {...common}><rect x="6" y="6" width="36" height="36" rx="8"/><circle cx="24" cy="24" r="8"/><circle cx="35" cy="13" r="2" fill={stroke}/></svg>);
    case "facebook":
      return (<svg {...common}><path d="M28 8h6v8h-6c-1 0-2 1-2 2v6h8l-2 8h-6v16h-8V32h-6v-8h6v-8a8 8 0 018-8z"/></svg>);
    case "whatsapp":
      return (<svg {...common}><path d="M24 4a20 20 0 00-17 30L4 44l10-3a20 20 0 1010-37z"/><path d="M16 18c0-2 2-4 4-4 1 0 2 4 2 5s-2 2-2 3c0 2 4 6 6 6 1 0 2-2 3-2s5 1 5 2c0 2-2 4-4 4-6 0-14-8-14-14z"/></svg>);
    default:
      return null;
  }
};

window.Icon = Icon;

// Main app for Direction A
const AppA = () => {
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);

  const addToCart = (p) => {
    setCart(prev => {
      const ex = prev.find(x => x.id === p.id);
      if (ex) return prev.map(x => x.id === p.id ? { ...x, qty: x.qty + 1 } : x);
      return [...prev, { ...p, qty: 1 }];
    });
  };
  const removeFromCart = (id) => setCart(prev => prev.filter(x => x.id !== id));

  return (
    <div style={{ fontFamily: "'Manrope', 'Inter', system-ui, sans-serif", background: A.cream }}>
      <HeaderA onCart={() => setCartOpen(true)} cartCount={cart.reduce((s, x) => s + x.qty, 0)} />
      <HeroA />
      <ServiziA />
      <ChiSiamoA />
      <ShopA onAdd={addToCart} />
      <RecensioniA />
      <GalleriaA />
      <DoveA />
      <FooterA />
      <CartDrawer open={cartOpen} items={cart} onClose={() => setCartOpen(false)} onRemove={removeFromCart} />
    </div>
  );
};

window.AppA = AppA;

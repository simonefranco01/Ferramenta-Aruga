// Direction C — Part 2: Storia, Shop, Recensioni, Galleria, Dove, Footer, App

const StoriaC = () => {
  const [ref, v] = useRevealC();
  return (
    <section id="chi-c" style={{ background: C.blue, color: "#fff", padding: "120px 0", position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, backgroundImage: `radial-gradient(circle, ${C.yellow}22 2px, transparent 2px)`, backgroundSize: "30px 30px" }} />
      <div ref={ref} style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px", position: "relative", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }}>
        <div>
          <div style={{ display: "inline-block", background: C.red, color: "#fff", padding: "6px 16px", borderRadius: 99, fontWeight: 900, border: `2px solid ${C.ink}`, transform: "rotate(-2deg)", fontSize: 12, letterSpacing: "0.15em", boxShadow: `2px 2px 0 ${C.ink}` }}>★ DAL 1986</div>
          <h2 style={{ fontSize: "clamp(44px, 7vw, 88px)", fontFamily: "'Rubik', sans-serif", fontWeight: 900, color: C.yellow, letterSpacing: "-0.03em", lineHeight: 0.95, margin: "20px 0", WebkitTextStroke: `2px ${C.ink}` }}>
            Una bottega, <span style={{ color: "#fff" }}>una famiglia.</span>
          </h2>
          <p style={{ fontSize: 18, lineHeight: 1.6, opacity: 0.95, maxWidth: 520 }}>
            Nel 1986 abbiamo alzato per la prima volta la saracinesca. Da allora sono passati migliaia di clienti, altrettanti consigli e chissà quante chiavi duplicate. Quello che non è cambiato: due mani disponibili, un banco sempre ordinato, e la voglia di risolvere i problemi della gente del quartiere.
          </p>
          <div style={{ marginTop: 40, display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
            {[["40","anni"],["11","reparti"],["4.9★","Google"]].map(([b, s], i) => (
              <Sticker key={i} rot={(i - 1) * 4} color={[C.yellow, C.red, "#fff"][i]} size={130}>
                <div style={{ textAlign: "center", color: C.ink }}>
                  <div style={{ fontSize: 32, fontWeight: 900, fontFamily: "'Rubik', sans-serif", lineHeight: 1 }}>{b}</div>
                  <div style={{ fontSize: 11, fontWeight: 800, textTransform: "uppercase", marginTop: 2 }}>{s}</div>
                </div>
              </Sticker>
            ))}
          </div>
        </div>
        <div style={{ position: "relative", aspectRatio: "1" }}>
          <div style={{ position: "absolute", top: "10%", left: "10%", width: "65%", aspectRatio: 1, background: C.yellow, border: `4px solid ${C.ink}`, boxShadow: `8px 8px 0 ${C.ink}`, transform: "rotate(-4deg)", overflow: "hidden" }}>
            <img src="assets/logo-aruga.jpeg" alt="Aruga" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
          <div style={{ position: "absolute", top: "35%", right: "0%", width: "55%", background: "#fff", color: C.ink, border: `3px solid ${C.ink}`, padding: 20, boxShadow: `6px 6px 0 ${C.ink}`, transform: "rotate(3deg)" }}>
            <Icon name="quote" size={26} stroke={C.red} />
            <p style={{ margin: "8px 0", fontSize: 15, lineHeight: 1.4, fontStyle: "italic" }}>"Robi & Robi che squadra! Hanno sempre una soluzione... e quando non ce l'hanno la inventano nel retrobottega."</p>
            <div style={{ fontSize: 12, fontWeight: 800, color: C.blue }}>— ANGELO C.</div>
          </div>
          <div style={{ position: "absolute", bottom: "5%", left: "0%", background: C.red, color: "#fff", padding: "12px 20px", borderRadius: 99, border: `3px solid ${C.ink}`, fontWeight: 900, transform: "rotate(-5deg)", boxShadow: `4px 4px 0 ${C.ink}` }}>
            Ferramenta di fiducia
          </div>
        </div>
      </div>
    </section>
  );
};

const ShopC = ({ onAdd }) => {
  const [cat, setCat] = uC("Tutti");
  const cats = mC(() => ["Tutti", ...new Set(PRODOTTI.map(p => p.cat))], []);
  const shown = cat === "Tutti" ? PRODOTTI : PRODOTTI.filter(p => p.cat === cat);
  return (
    <section id="shop-c" style={{ background: C.cream, padding: "120px 0" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px" }}>
        <div style={{ textAlign: "center", marginBottom: 40 }}>
          <div style={{ display: "inline-block", background: C.red, color: "#fff", padding: "6px 16px", borderRadius: 99, fontWeight: 900, border: `2px solid ${C.ink}`, fontSize: 12, letterSpacing: "0.15em", boxShadow: `2px 2px 0 ${C.ink}` }}>SHOP</div>
          <h2 style={{ fontSize: "clamp(44px, 7vw, 88px)", fontFamily: "'Rubik', sans-serif", fontWeight: 900, color: C.blue, letterSpacing: "-0.03em", margin: "20px 0 16px" }}>
            Ordina da casa, <span style={{ color: C.red }}>ritira in bottega.</span>
          </h2>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", marginBottom: 40 }}>
          {cats.map((c, i) => (
            <button key={c} onClick={() => setCat(c)} style={{
              padding: "10px 18px", borderRadius: 99,
              background: cat === c ? C.blue : "#fff", color: cat === c ? C.yellow : C.blue,
              border: `2.5px solid ${C.ink}`, fontWeight: 800, fontSize: 13, cursor: "pointer", fontFamily: "inherit",
              boxShadow: cat === c ? `3px 3px 0 ${C.ink}` : `2px 2px 0 ${C.ink}`,
              transform: `rotate(${(i % 2 === 0 ? -1 : 1) * 0.5}deg)`,
            }}>{c}</button>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 20 }}>
          {shown.map((p, i) => <ProductCardC key={p.id} p={p} i={i} onAdd={onAdd} />)}
        </div>
      </div>
    </section>
  );
};

const ProductCardC = ({ p, i, onAdd }) => {
  const [ref, v] = useRevealC();
  const [added, setAdded] = uC(false);
  const [hover, setHover] = uC(false);
  const handle = () => { onAdd(p); setAdded(true); setTimeout(() => setAdded(false), 1200); };
  const rot = (i % 2 === 0 ? 1 : -1) * (0.8 + (i % 3) * 0.4);
  return (
    <div ref={ref} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: "#fff", border: `3px solid ${C.ink}`, borderRadius: 18,
        boxShadow: hover ? `8px 8px 0 ${C.ink}` : `4px 4px 0 ${C.ink}`,
        display: "flex", flexDirection: "column",
        opacity: v ? 1 : 0, transform: v ? `rotate(${hover ? 0 : rot}deg) translateY(${hover ? -4 : 0}px)` : "translateY(20px)",
        transition: `all .4s ${i * 0.03}s`, overflow: "hidden", position: "relative",
    }}>
      {p.offerta && <span style={{ position: "absolute", top: 10, right: 10, zIndex: 2, background: C.red, color: "#fff", padding: "4px 10px", borderRadius: 99, fontWeight: 900, fontSize: 11, border: `2px solid ${C.ink}`, transform: "rotate(6deg)" }}>OFFERTA!</span>}
      <div style={{ aspectRatio: "1", background: p.colore, display: "grid", placeItems: "center", fontSize: 80, borderBottom: `3px solid ${C.ink}` }}>
        <div style={{ transform: hover ? "scale(1.15) rotate(-8deg)" : "none", transition: "transform .3s" }}>{p.emoji}</div>
      </div>
      <div style={{ padding: 16, flex: 1, display: "flex", flexDirection: "column" }}>
        <div style={{ fontSize: 10, fontWeight: 900, color: C.red, letterSpacing: "0.12em" }}>{p.cat.toUpperCase()}</div>
        <h4 style={{ margin: "4px 0 10px", fontSize: 15, fontWeight: 800, color: C.ink, lineHeight: 1.3, flex: 1 }}>{p.nome}</h4>
        <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: 10 }}>
          <div>
            {p.prezzoVecchio && <span style={{ textDecoration: "line-through", opacity: 0.5, fontSize: 12, marginRight: 4 }}>€{p.prezzoVecchio.toFixed(2)}</span>}
            <span style={{ fontSize: 22, fontWeight: 900, color: C.blue, fontFamily: "'Rubik', sans-serif" }}>€{p.prezzo.toFixed(2)}</span>
          </div>
        </div>
        <button onClick={handle} style={{
          background: added ? C.green : C.blue, color: C.yellow,
          border: `2.5px solid ${C.ink}`, padding: "10px", borderRadius: 99,
          fontWeight: 900, fontSize: 13, cursor: "pointer", fontFamily: "inherit",
          display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
          boxShadow: `3px 3px 0 ${C.ink}`,
        }}>
          {added ? <><Icon name="check" size={14} stroke={C.yellow} /> AGGIUNTO!</> : <><Icon name="plus" size={14} stroke={C.yellow} /> AGGIUNGI</>}
        </button>
      </div>
    </div>
  );
};

const RecensioniC = () => {
  const colors = ["#fff", C.yellow, C.red, C.green, C.yellow, "#fff", C.blue, C.red];
  return (
    <section id="rec-c" style={{ background: C.paper, padding: "120px 0", overflow: "hidden" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px", marginBottom: 50, textAlign: "center" }}>
        <div style={{ display: "inline-block", background: C.yellow, padding: "6px 16px", borderRadius: 99, fontWeight: 900, border: `2px solid ${C.ink}`, fontSize: 12, letterSpacing: "0.15em" }}>★ 4.9/5 SU GOOGLE</div>
        <h2 style={{ fontSize: "clamp(44px, 7vw, 88px)", fontFamily: "'Rubik', sans-serif", fontWeight: 900, color: C.blue, letterSpacing: "-0.03em", margin: "20px 0 0", lineHeight: 1 }}>
          Parole <span style={{ color: C.red }}>nostre?</span> No, <span style={{ fontStyle: "italic" }}>loro.</span>
        </h2>
      </div>
      {[RECENSIONI.slice(0, 8), RECENSIONI.slice(8, 16)].map((row, ri) => (
        <div key={ri} style={{ display: "flex", gap: 24, marginBottom: 24, width: "max-content", animation: `scroll-left ${45 + ri * 10}s linear infinite`, animationDirection: ri % 2 === 0 ? "normal" : "reverse" }}>
          {[...row, ...row].map((r, i) => {
            const bg = colors[i % colors.length];
            const dark = bg === C.blue || bg === C.red || bg === C.green;
            const fg = dark ? "#fff" : C.ink;
            const rot = (i % 2 === 0 ? -1 : 1) * (1 + (i % 3) * 0.5);
            return (
              <div key={`${ri}-${i}`} style={{ width: 340, flexShrink: 0, background: bg, color: fg, border: `3px solid ${C.ink}`, borderRadius: 22, padding: 22, boxShadow: `5px 5px 0 ${C.ink}`, transform: `rotate(${rot}deg)` }}>
                <div style={{ display: "flex", gap: 2, marginBottom: 10 }}>{Array.from({ length: r.stelle }).map((_, k) => <Icon key={k} name="star" size={18} stroke={C.red} />)}</div>
                <p style={{ fontSize: 15, lineHeight: 1.5, margin: "0 0 14px" }}>"{r.testo}"</p>
                <div style={{ fontWeight: 900, fontSize: 13 }}>{r.nome}</div>
                <div style={{ fontSize: 12, opacity: 0.7 }}>{r.quando}</div>
              </div>
            );
          })}
        </div>
      ))}
    </section>
  );
};

const GalleriaC = () => {
  const tiles = [
    { bg: C.red, icon: "hammer", label: "Utensileria" },
    { bg: C.blue, icon: "drill", label: "Elettroutensili" },
    { bg: C.green, icon: "key", label: "Chiavi" },
    { bg: C.yellow, icon: "paint", label: "Vernici" },
    { bg: C.yellowDark, icon: "bolt", label: "Minuteria" },
    { bg: C.blue, icon: "leaf", label: "Giardino" },
  ];
  return (
    <section style={{ background: C.cream, padding: "120px 0" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px" }}>
        <div style={{ textAlign: "center", marginBottom: 50 }}>
          <div style={{ display: "inline-block", background: C.yellow, padding: "6px 16px", borderRadius: 99, fontWeight: 900, border: `2px solid ${C.ink}`, fontSize: 12, letterSpacing: "0.15em" }}>DENTRO IL NEGOZIO</div>
          <h2 style={{ fontSize: "clamp(44px, 7vw, 80px)", fontFamily: "'Rubik', sans-serif", fontWeight: 900, color: C.blue, letterSpacing: "-0.03em", margin: "20px 0 0" }}>
            Un <span style={{ color: C.red }}>tour</span> in bottega.
          </h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20, gridAutoRows: "240px" }}>
          {tiles.map((t, i) => {
            const dark = [C.blue, C.red, C.green].includes(t.bg);
            const fg = dark ? C.yellow : C.ink;
            const rot = (i % 2 === 0 ? -1 : 1) * 1.2;
            return (
              <div key={i} style={{ background: t.bg, border: `3px solid ${C.ink}`, borderRadius: 20, boxShadow: `5px 5px 0 ${C.ink}`, display: "grid", placeItems: "center", position: "relative", overflow: "hidden", transform: `rotate(${rot}deg)` }}>
                <Icon name={t.icon} size={100} stroke={fg} sw={2} />
                <div style={{ position: "absolute", bottom: 16, left: 16, background: "#fff", color: C.ink, padding: "6px 14px", borderRadius: 99, fontWeight: 900, fontSize: 13, border: `2px solid ${C.ink}` }}>{t.label}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

const DoveC = () => (
  <section id="dove-c" style={{ background: C.yellow, padding: "120px 0", position: "relative", overflow: "hidden" }}>
    <div style={{ position: "absolute", inset: 0, backgroundImage: `radial-gradient(circle, ${C.ink}11 2px, transparent 2px)`, backgroundSize: "30px 30px" }} />
    <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px", position: "relative" }}>
      <div style={{ textAlign: "center", marginBottom: 50 }}>
        <div style={{ display: "inline-block", background: C.blue, color: C.yellow, padding: "6px 16px", borderRadius: 99, fontWeight: 900, border: `2px solid ${C.ink}`, fontSize: 12, letterSpacing: "0.15em", boxShadow: `2px 2px 0 ${C.ink}` }}>VIENI A TROVARCI</div>
        <h2 style={{ fontSize: "clamp(44px, 7vw, 88px)", fontFamily: "'Rubik', sans-serif", fontWeight: 900, color: C.blue, letterSpacing: "-0.03em", margin: "20px 0 0", WebkitTextStroke: `2px ${C.ink}`, textShadow: `4px 4px 0 ${C.red}` }}>
          Via Graglia 6, <span style={{ color: C.red }}>Torino.</span>
        </h2>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 28 }}>
        <div style={{ aspectRatio: "1.4", border: `4px solid ${C.ink}`, borderRadius: 20, overflow: "hidden", boxShadow: `8px 8px 0 ${C.ink}`, background: "#ddd" }}>
          <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=7.6508%2C45.0731%2C7.6588%2C45.0791&layer=mapnik&marker=45.0761%2C7.6548" style={{ border: 0, width: "100%", height: "100%" }} loading="lazy" title="mappa" />
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <InfoC icon="pin" title="INDIRIZZO" big="Via Graglia, 6" sub="10136 Torino" href="https://www.google.com/maps?q=Via+Graglia+6+Torino" color={C.red} fg="#fff" />
          <InfoC icon="phone" title="TELEFONO" big="011 353934" sub="Chiamaci quando vuoi" href="tel:+390113539340" color={C.blue} fg={C.yellow} />
          <div style={{ background: "#fff", border: `3px solid ${C.ink}`, borderRadius: 18, padding: 18, boxShadow: `5px 5px 0 ${C.ink}` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, letterSpacing: "0.2em", fontWeight: 900, color: C.red, marginBottom: 10 }}>
              <Icon name="clock" size={14} stroke={C.red} /> ORARI
            </div>
            {CONTATTI.orari.map(o => (
              <div key={o.g} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", fontSize: 13, color: C.ink, borderBottom: `1px dashed ${C.ink}33` }}>
                <span style={{ fontWeight: 700 }}>{o.g}</span>
                <span>{o.h}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const InfoC = ({ icon, title, big, sub, href, color, fg }) => (
  <a href={href} target="_blank" rel="noopener" style={{ background: color, color: fg, border: `3px solid ${C.ink}`, borderRadius: 18, padding: 20, textDecoration: "none", boxShadow: `5px 5px 0 ${C.ink}`, transition: "transform .15s" }}
    onMouseEnter={e => e.currentTarget.style.transform = "translate(-3px,-3px)"}
    onMouseLeave={e => e.currentTarget.style.transform = ""}>
    <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, letterSpacing: "0.2em", fontWeight: 900 }}>
      <Icon name={icon} size={16} stroke={fg} /> {title}
    </div>
    <div style={{ fontSize: 26, fontFamily: "'Rubik', sans-serif", fontWeight: 900, letterSpacing: "-0.02em", marginTop: 6 }}>{big}</div>
    <div style={{ fontSize: 13, opacity: 0.9 }}>{sub}</div>
  </a>
);

const FooterC = () => (
  <footer style={{ background: C.ink, color: C.yellow, padding: "60px 0 24px" }}>
    <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 28px" }}>
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 30, paddingBottom: 30, borderBottom: `2px dashed ${C.yellow}44` }}>
        <div>
          <div style={{ fontSize: 32, fontWeight: 900, fontFamily: "'Rubik', sans-serif", letterSpacing: "-0.02em", color: C.yellow }}>Aruga</div>
          <div style={{ fontSize: 12, color: C.red, fontWeight: 800, letterSpacing: "0.2em", marginTop: 2 }}>FERRAMENTA DAL 1986</div>
          <p style={{ fontSize: 14, marginTop: 18, opacity: 0.8, maxWidth: 320 }}>La tua bottega in Via Graglia 6, Torino. Utensili, chiavi, consigli e riparazioni a domicilio.</p>
          <div style={{ marginTop: 18, display: "flex", gap: 10 }}>
            {["facebook","instagram","whatsapp"].map(i => (
              <a key={i} href="#" style={{ width: 42, height: 42, borderRadius: "50%", background: C.yellow, color: C.ink, display: "grid", placeItems: "center", border: `2px solid ${C.yellow}`, transition: "transform .15s" }} onMouseEnter={e => e.currentTarget.style.transform = "rotate(-8deg) scale(1.08)"} onMouseLeave={e => e.currentTarget.style.transform = ""}>
                <Icon name={i} size={20} stroke={C.ink} />
              </a>
            ))}
          </div>
        </div>
        {[["NEGOZIO",["Reparti","Shop","Storia","Galleria"]],["CONTATTI",["Via Graglia 6","Torino","011 353934","Lun-Sab"]],["LEGALE",["P.IVA","Privacy","Cookie"]]].map(([t, items]) => (
          <div key={t}>
            <div style={{ fontSize: 12, fontWeight: 900, letterSpacing: "0.2em", color: C.red, marginBottom: 12 }}>{t}</div>
            {items.map(x => <div key={x} style={{ fontSize: 14, padding: "3px 0", opacity: 0.85 }}>{x}</div>)}
          </div>
        ))}
      </div>
      <div style={{ paddingTop: 20, textAlign: "center", fontSize: 12, opacity: 0.55 }}>© 2026 Ferramenta Aruga · Via Graglia 6, 10136 Torino · P.IVA 0000000000</div>
    </div>
  </footer>
);

const CartDrawerC = ({ open, items, onClose, onRemove }) => {
  const total = items.reduce((s, x) => s + x.prezzo * x.qty, 0);
  return (
    <>
      <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 200, opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none", transition: "opacity .3s" }} onClick={onClose} />
      <aside style={{ position: "fixed", top: 0, right: 0, bottom: 0, width: "min(420px, 92vw)", background: C.cream, zIndex: 201, transform: open ? "translateX(0)" : "translateX(100%)", transition: "transform .35s", display: "flex", flexDirection: "column", borderLeft: `4px solid ${C.ink}` }}>
        <div style={{ background: C.red, color: "#fff", padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: `3px solid ${C.ink}` }}>
          <div style={{ fontSize: 22, fontWeight: 900, fontFamily: "'Rubik', sans-serif" }}>IL TUO CARRELLO</div>
          <button onClick={onClose} style={{ background: "transparent", border: "none", cursor: "pointer", padding: 4, color: "#fff" }}><Icon name="close" size={22} stroke="#fff" /></button>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: 16 }}>
          {items.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px", color: C.blue }}>
              <Icon name="cart" size={60} stroke={C.blue} sw={2} />
              <div style={{ fontFamily: "'Rubik', sans-serif", fontSize: 22, fontWeight: 900, marginTop: 12 }}>Vuoto!</div>
              <div style={{ fontSize: 14, opacity: 0.7, marginTop: 6 }}>Aggiungi qualcosa dallo shop.</div>
            </div>
          ) : items.map(it => (
            <div key={it.id} style={{ background: "#fff", border: `2.5px solid ${C.ink}`, borderRadius: 14, padding: 12, marginBottom: 10, display: "flex", gap: 12, alignItems: "center", boxShadow: `3px 3px 0 ${C.ink}` }}>
              <div style={{ width: 52, height: 52, background: it.colore, display: "grid", placeItems: "center", fontSize: 26, borderRadius: 10, border: `2px solid ${C.ink}` }}>{it.emoji}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: C.ink }}>{it.nome}</div>
                <div style={{ fontSize: 12, opacity: 0.6 }}>Qtà {it.qty}</div>
                <div style={{ fontSize: 15, fontWeight: 900, color: C.blue, fontFamily: "'Rubik', sans-serif" }}>€{(it.prezzo * it.qty).toFixed(2)}</div>
              </div>
              <button onClick={() => onRemove(it.id)} style={{ background: "transparent", border: "none", cursor: "pointer" }}><Icon name="close" size={18} stroke={C.red} /></button>
            </div>
          ))}
        </div>
        <div style={{ background: C.blue, color: C.yellow, padding: 20, borderTop: `3px solid ${C.ink}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 22, fontWeight: 900, marginBottom: 14, fontFamily: "'Rubik', sans-serif" }}>
            <span>TOTALE</span><span>€{total.toFixed(2)}</span>
          </div>
          <button disabled={!items.length} style={{ width: "100%", padding: "14px", background: C.yellow, color: C.blue, border: `2.5px solid ${C.ink}`, borderRadius: 99, fontWeight: 900, fontSize: 15, cursor: items.length ? "pointer" : "not-allowed", fontFamily: "inherit", boxShadow: `4px 4px 0 ${C.ink}` }}>VAI AL CHECKOUT →</button>
        </div>
      </aside>
    </>
  );
};

const AppC = () => {
  const [cart, setCart] = uC([]);
  const [open, setOpen] = uC(false);
  const add = (p) => setCart(prev => {
    const ex = prev.find(x => x.id === p.id);
    if (ex) return prev.map(x => x.id === p.id ? { ...x, qty: x.qty + 1 } : x);
    return [...prev, { ...p, qty: 1 }];
  });
  const rem = (id) => setCart(prev => prev.filter(x => x.id !== id));
  return (
    <div style={{ fontFamily: "'Rubik', 'Inter', system-ui, sans-serif", background: C.cream, color: C.ink }}>
      <HeaderC onCart={() => setOpen(true)} count={cart.reduce((s, x) => s + x.qty, 0)} />
      <HeroC />
      <ServiziC />
      <StoriaC />
      <ShopC onAdd={add} />
      <RecensioniC />
      <GalleriaC />
      <DoveC />
      <FooterC />
      <CartDrawerC open={open} items={cart} onClose={() => setOpen(false)} onRemove={rem} />
    </div>
  );
};

window.AppC = AppC;

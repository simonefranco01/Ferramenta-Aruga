// Direction B — Part 2: Recensioni carousel, Dove, Footer, Gallery, App

const RecensioniB = () => {
  const [idx, setIdx] = uB(0);
  const perView = 3;
  const max = Math.max(0, RECENSIONI.length - perView);
  eB(() => {
    const t = setInterval(() => setIdx(p => p >= max ? 0 : p + 1), 4500);
    return () => clearInterval(t);
  }, [max]);
  return (
    <section id="recensioni-b" style={{ background: B.ink, color: B.cream, padding: "140px 0", overflow: "hidden" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 60, flexWrap: "wrap", gap: 20 }}>
          <div>
            <div style={{ fontSize: 12, color: B.yellow, letterSpacing: "0.25em", fontWeight: 600, textTransform: "uppercase" }}>— Recensioni</div>
            <h2 style={{ fontSize: "clamp(44px, 6vw, 80px)", fontFamily: "'Fraunces', serif", fontWeight: 400, lineHeight: 1, color: B.cream, letterSpacing: "-0.04em", marginTop: 16 }}>
              Le parole dei <span style={{ fontStyle: "italic", color: B.yellow }}>clienti.</span>
            </h2>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ display: "flex", gap: 4, justifyContent: "flex-end" }}>{[1,2,3,4,5].map(s => <Icon key={s} name="star" size={24} stroke={B.yellow} />)}</div>
            <div style={{ fontSize: 48, fontFamily: "'Fraunces', serif", fontWeight: 500, marginTop: 8 }}>4.9 / 5</div>
            <div style={{ fontSize: 13, opacity: 0.6 }}>oltre 60 recensioni Google</div>
          </div>
        </div>
        <div style={{ overflow: "hidden" }}>
          <div style={{
            display: "flex", gap: 24,
            transform: `translateX(calc(-${idx} * (100% / ${perView}) - ${idx * 24}px))`,
            transition: "transform .8s cubic-bezier(.5,0,.2,1)",
          }}>
            {RECENSIONI.map((r, i) => (
              <div key={i} style={{ flex: `0 0 calc((100% - ${(perView - 1) * 24}px) / ${perView})` }}>
                <div style={{ background: i % 2 ? B.blue : "transparent", border: `1px solid ${B.cream}33`, padding: 32, minHeight: 260, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
                  <div>
                    <Icon name="quote" size={32} stroke={B.yellow} />
                    <p style={{ fontSize: 17, lineHeight: 1.5, margin: "16px 0 0", fontFamily: "'Fraunces', serif", fontStyle: "italic", color: B.cream }}>"{r.testo}"</p>
                  </div>
                  <div style={{ marginTop: 24, display: "flex", justifyContent: "space-between", alignItems: "end", borderTop: `1px solid ${B.cream}22`, paddingTop: 14 }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{r.nome}</div>
                      <div style={{ fontSize: 12, opacity: 0.6 }}>{r.quando}</div>
                    </div>
                    <div style={{ display: "flex", gap: 2 }}>{Array.from({ length: r.stelle }).map((_, k) => <Icon key={k} name="star" size={12} stroke={B.yellow} />)}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 40 }}>
          <button onClick={() => setIdx(Math.max(0, idx - 1))} style={arrowBtnB}><Icon name="arrow" size={18} stroke={B.cream} /></button>
          <button onClick={() => setIdx(Math.min(max, idx + 1))} style={{ ...arrowBtnB, transform: "scaleX(-1)" }}><Icon name="arrow" size={18} stroke={B.cream} /></button>
        </div>
      </div>
    </section>
  );
};

const arrowBtnB = {
  width: 52, height: 52, borderRadius: "50%",
  background: "transparent", border: `1.5px solid ${B.cream}44`, color: B.cream,
  cursor: "pointer", display: "grid", placeItems: "center",
};

const GalleriaB = () => {
  const tiles = [
    { bg: B.yellow, icon: "hammer", label: "Utensileria" },
    { bg: B.blue, icon: "drill", label: "Elettroutensili" },
    { bg: B.accent, icon: "key", label: "Chiavi" },
    { bg: B.yellowSoft, icon: "paint", label: "Vernici" },
    { bg: B.blueSoft, icon: "bolt", label: "Minuteria" },
    { bg: B.yellow, icon: "leaf", label: "Giardinaggio" },
  ];
  return (
    <section style={{ background: B.cream, padding: "140px 0" }}>
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px" }}>
        <div style={{ fontSize: 12, color: B.accent, letterSpacing: "0.25em", fontWeight: 600, textTransform: "uppercase" }}>— Galleria</div>
        <h2 style={{ fontSize: "clamp(44px, 6vw, 80px)", fontFamily: "'Fraunces', serif", fontWeight: 400, lineHeight: 1, color: B.ink, letterSpacing: "-0.04em", margin: "16px 0 60px" }}>
          Dentro la <span style={{ fontStyle: "italic" }}>bottega.</span>
        </h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gridAutoRows: "260px", gap: 12 }}>
          {tiles.map((t, i) => {
            const fg = (t.bg === B.blue || t.bg === B.accent || t.bg === B.blueSoft) ? B.cream : B.ink;
            return (
              <div key={i} style={{
                background: t.bg, display: "grid", placeItems: "center", position: "relative", overflow: "hidden",
                gridColumn: i === 0 ? "span 2" : "span 1",
                gridRow: i === 0 ? "span 2" : "span 1",
              }}>
                <Icon name={t.icon} size={i === 0 ? 200 : 100} stroke={fg} sw={1.5} />
                <div style={{ position: "absolute", bottom: 20, left: 20, color: fg, fontFamily: "'Fraunces', serif", fontStyle: "italic", fontSize: 20 }}>{t.label}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

const DoveB = () => (
  <section id="dove-b" style={{ background: B.creamDark, padding: "140px 0" }}>
    <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px" }}>
      <div style={{ fontSize: 12, color: B.accent, letterSpacing: "0.25em", fontWeight: 600, textTransform: "uppercase" }}>— Dove siamo</div>
      <h2 style={{ fontSize: "clamp(44px, 6vw, 80px)", fontFamily: "'Fraunces', serif", fontWeight: 400, lineHeight: 1, color: B.ink, letterSpacing: "-0.04em", margin: "16px 0 60px" }}>
        Via Graglia 6, <span style={{ fontStyle: "italic" }}>Torino.</span>
      </h2>
      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 32 }}>
        <div style={{ aspectRatio: "1.4", background: "#ddd", overflow: "hidden" }}>
          <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=7.6508%2C45.0731%2C7.6588%2C45.0791&layer=mapnik&marker=45.0761%2C7.6548" style={{ border: 0, width: "100%", height: "100%" }} loading="lazy" title="mappa" />
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <InfoB icon="pin" label="INDIRIZZO" val="Via Graglia, 6 — 10136 Torino" href="https://www.google.com/maps?q=Via+Graglia+6+Torino" />
          <InfoB icon="phone" label="TELEFONO" val="011 353934" href="tel:+390113539340" />
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, letterSpacing: "0.25em", color: B.accent, fontWeight: 600, marginBottom: 12 }}>
              <Icon name="clock" size={14} stroke={B.accent} /> ORARI
            </div>
            {CONTATTI.orari.map(o => (
              <div key={o.g} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", fontSize: 15, color: B.ink, borderBottom: `1px solid ${B.ink}15` }}>
                <span style={{ fontWeight: 500 }}>{o.g}</span>
                <span style={{ fontFamily: "'Fraunces', serif", fontStyle: "italic" }}>{o.h}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const InfoB = ({ icon, label, val, href }) => (
  <a href={href} target="_blank" rel="noopener" style={{ textDecoration: "none", display: "block", padding: 20, background: B.cream, transition: "transform .15s" }}
    onMouseEnter={e => e.currentTarget.style.transform = "translateX(4px)"}
    onMouseLeave={e => e.currentTarget.style.transform = ""}>
    <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, letterSpacing: "0.25em", color: B.accent, fontWeight: 600, marginBottom: 8 }}>
      <Icon name={icon} size={14} stroke={B.accent} /> {label}
    </div>
    <div style={{ fontSize: 24, fontFamily: "'Fraunces', serif", fontWeight: 500, color: B.ink, letterSpacing: "-0.02em" }}>{val}</div>
  </a>
);

const FooterB = () => (
  <footer style={{ background: B.ink, color: B.cream, padding: "80px 0 30px" }}>
    <div style={{ maxWidth: 1400, margin: "0 auto", padding: "0 32px" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr 1fr 1fr", gap: 40, paddingBottom: 40, borderBottom: `1px solid ${B.cream}22` }}>
        <div>
          <div style={{ fontSize: 32, fontFamily: "'Fraunces', serif", fontWeight: 500, letterSpacing: "-0.02em" }}>Aruga</div>
          <div style={{ fontSize: 13, opacity: 0.6, letterSpacing: "0.15em", marginTop: 4 }}>FERRAMENTA · DAL 1986</div>
          <p style={{ fontSize: 14, lineHeight: 1.6, opacity: 0.75, marginTop: 20, maxWidth: 320 }}>
            La bottega di quartiere in via Graglia 6, Torino. Utensili, consigli e riparazioni a domicilio.
          </p>
        </div>
        <div>
          <div style={{ fontSize: 12, letterSpacing: "0.2em", color: B.yellow, marginBottom: 12, fontWeight: 600 }}>NEGOZIO</div>
          {["Servizi","Catalogo","Storia","Galleria"].map(x => <div key={x} style={{ fontSize: 14, padding: "4px 0", opacity: 0.85 }}>{x}</div>)}
        </div>
        <div>
          <div style={{ fontSize: 12, letterSpacing: "0.2em", color: B.yellow, marginBottom: 12, fontWeight: 600 }}>CONTATTI</div>
          <div style={{ fontSize: 14, padding: "4px 0", opacity: 0.85 }}>Via Graglia 6, Torino</div>
          <div style={{ fontSize: 14, padding: "4px 0", opacity: 0.85 }}>011 353934</div>
        </div>
        <div>
          <div style={{ fontSize: 12, letterSpacing: "0.2em", color: B.yellow, marginBottom: 12, fontWeight: 600 }}>SEGUICI</div>
          <div style={{ display: "flex", gap: 10 }}>
            {["facebook","instagram","whatsapp"].map(i => (
              <a key={i} href="#" style={{ width: 40, height: 40, borderRadius: "50%", border: `1.5px solid ${B.cream}44`, display: "grid", placeItems: "center" }}>
                <Icon name={i} size={18} stroke={B.cream} />
              </a>
            ))}
          </div>
        </div>
      </div>
      <div style={{ paddingTop: 24, fontSize: 12, opacity: 0.5, textAlign: "center" }}>© 2026 Ferramenta Aruga · P.IVA 0000000000</div>
    </div>
  </footer>
);

// Cart drawer reused style
const CartDrawerB = ({ open, items, onClose, onRemove }) => {
  const total = items.reduce((s, x) => s + x.prezzo * x.qty, 0);
  return (
    <>
      <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 200, opacity: open ? 1 : 0, pointerEvents: open ? "auto" : "none", transition: "opacity .3s" }} onClick={onClose} />
      <aside style={{ position: "fixed", top: 0, right: 0, bottom: 0, width: "min(420px, 92vw)", background: B.cream, zIndex: 201, transform: open ? "translateX(0)" : "translateX(100%)", transition: "transform .35s", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "24px 28px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: `1px solid ${B.ink}22` }}>
          <div style={{ fontSize: 24, fontFamily: "'Fraunces', serif", fontWeight: 500, color: B.ink }}>Il tuo carrello</div>
          <button onClick={onClose} style={{ background: "transparent", border: "none", cursor: "pointer", padding: 4, color: B.ink }}><Icon name="close" size={22} stroke={B.ink} /></button>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: 20 }}>
          {items.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px", color: B.ink }}>
              <Icon name="cart" size={56} stroke={B.ink} sw={1.5} />
              <div style={{ fontFamily: "'Fraunces', serif", fontSize: 22, marginTop: 16, fontStyle: "italic" }}>Il carrello è vuoto.</div>
            </div>
          ) : items.map(it => (
            <div key={it.id} style={{ display: "flex", gap: 14, padding: "14px 0", borderBottom: `1px solid ${B.ink}15`, alignItems: "center" }}>
              <div style={{ width: 54, height: 54, background: it.colore, display: "grid", placeItems: "center", fontSize: 28 }}>{it.emoji}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontFamily: "'Fraunces', serif", color: B.ink }}>{it.nome}</div>
                <div style={{ fontSize: 12, opacity: 0.6, color: B.ink }}>Qtà {it.qty} · €{(it.prezzo * it.qty).toFixed(2)}</div>
              </div>
              <button onClick={() => onRemove(it.id)} style={{ background: "transparent", border: "none", cursor: "pointer", padding: 4 }}><Icon name="close" size={16} stroke={B.accent} /></button>
            </div>
          ))}
        </div>
        <div style={{ padding: 24, borderTop: `1px solid ${B.ink}22` }}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 20, fontFamily: "'Fraunces', serif", marginBottom: 16, color: B.ink }}>
            <span>Totale</span><span style={{ fontWeight: 600 }}>€{total.toFixed(2)}</span>
          </div>
          <button disabled={!items.length} style={{ width: "100%", padding: 16, background: B.ink, color: B.cream, border: "none", borderRadius: 99, fontWeight: 600, fontSize: 15, cursor: items.length ? "pointer" : "not-allowed", fontFamily: "inherit" }}>Vai al checkout</button>
        </div>
      </aside>
    </>
  );
};

const AppB = () => {
  const [cart, setCart] = uB([]);
  const [cartOpen, setCartOpen] = uB(false);
  const add = (p) => setCart(prev => {
    const ex = prev.find(x => x.id === p.id);
    if (ex) return prev.map(x => x.id === p.id ? { ...x, qty: x.qty + 1 } : x);
    return [...prev, { ...p, qty: 1 }];
  });
  const rem = (id) => setCart(prev => prev.filter(x => x.id !== id));
  return (
    <div style={{ fontFamily: "'Inter', system-ui, sans-serif", background: B.cream, color: B.ink }}>
      <HeaderB onCart={() => setCartOpen(true)} count={cart.reduce((s, x) => s + x.qty, 0)} />
      <HeroB />
      <ServiziB />
      <StoriaB />
      <ShopB onAdd={add} />
      <RecensioniB />
      <GalleriaB />
      <DoveB />
      <FooterB />
      <CartDrawerB open={cartOpen} items={cart} onClose={() => setCartOpen(false)} onRemove={rem} />
    </div>
  );
};

window.AppB = AppB;
